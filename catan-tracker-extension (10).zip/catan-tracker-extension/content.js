(function() {
  'use strict';

  // ═══════════════════════════════════════════════════════════════════════════════
  // CATAN TRACKER v3.1.0 — Colonist.io 1v1 + 4-player
  // ═══════════════════════════════════════════════════════════════════════════════

  const TRACKER_VERSION = "3.1.0";
  const TRACKER_ID = "catan-logtracker-root";

  console.log(`[Catan Tracker] Loading v${TRACKER_VERSION}...`);

  // ─────────────────────────────────────────────────────────────────────────────
  // SECTION 1: CONSTANTS & CONFIGURATION
  // ─────────────────────────────────────────────────────────────────────────────

  const RESOURCES = ["lumber", "brick", "wool", "grain", "ore"];

  const RESOURCE_ICONS = {
    lumber: "🌲",
    brick: "🧱",
    wool: "🐑",
    grain: "🌾",
    ore: "⛰️"
  };

  const RESOURCE_NAME_MAP = {
    "Brick": "brick", "Lumber": "lumber", "Wool": "wool", "Ore": "ore", "Grain": "grain",
    "brick": "brick", "lumber": "lumber", "wool": "wool", "ore": "ore", "grain": "grain",
    "wood": "lumber", "sheep": "wool", "wheat": "grain", "rock": "ore", "stone": "ore"
  };

  const DEV_CARD_TYPES = ["Knight", "Road Building", "Year of Plenty", "Monopoly", "Victory Point"];

  const DEV_CARD_TOTALS = {
    "Knight": 14,
    "Road Building": 2,
    "Year of Plenty": 2,
    "Monopoly": 2,
    "Victory Point": 5
  };

  const DEV_CARD_ICONS = {
    "Knight": "⚔️",
    "Road Building": "🛣️",
    "Year of Plenty": "🎁",
    "Monopoly": "💰",
    "Victory Point": "🏆"
  };

  const DEV_CARD_KEYS = {
    "Knight": "k",
    "Road Building": "rb",
    "Year of Plenty": "yop",
    "Monopoly": "m",
    "Victory Point": "vp"
  };

  // Total dev cards in the deck (14 + 2 + 2 + 2 + 5 = 25)
  const TOTAL_DEV_CARDS = 25;

  const BUILD_COSTS = {
    road: { brick: 1, lumber: 1 },
    settlement: { brick: 1, lumber: 1, wool: 1, grain: 1 },
    city: { grain: 2, ore: 3 },
    devCard: { wool: 1, grain: 1, ore: 1 }
  };

  const MAX_UNLOCKED_GAMES = 5;
  const MAX_DISPLAY_GAMES = 10;

  // Multiple selector patterns to try (Colonist.io updates their class names)
  const COLONIST_SELECTORS = {
    virtualScroller: [
      "div.virtualScroller-lSkdkGJi",
      "div[class*='virtualScroller']",
      ".log-container",
      "#game-log-container"
    ],
    scrollItemContainer: [
      "div.scrollItemContainer-WXX2rkzf",
      "div[class*='scrollItemContainer']",
      "[data-index]"
    ],
    feedMessage: [
      ".feedMessage-O8TLknGe",
      "[class*='feedMessage']",
      ".message",
      ".log-message"
    ],
    messagePart: [
      ".messagePart-XeUsOgLX",
      "[class*='messagePart']",
      ".message-content",
      "span"
    ]
  };

  // Helper to try multiple selectors
  function queryWithFallbacks(parent, selectors) {
    for (const sel of selectors) {
      try {
        const result = parent.querySelector(sel);
        if (result) return result;
      } catch (e) {}
    }
    return null;
  }

  function queryAllWithFallbacks(parent, selectors) {
    for (const sel of selectors) {
      try {
        const result = parent.querySelectorAll(sel);
        if (result && result.length > 0) return result;
      } catch (e) {}
    }
    return [];
  }

  const TIMING = {
    scanInterval: 350,
    saveDebounce: 100,
    renderDebounce: 50,
    rescanCollectInterval: 200,
    survivalCheckInterval: 1200
  };

  const STORAGE_KEYS = {
    state: "catan_logtracker_state",
    gameHistory: "catan_game_history",
    processedMessages: "catan_processed_messages_global",
    suppressConfirms: "catan_always_suppress_confirms",
    panelPosition: "catanTracker_panelPosition",
    panelCollapsed: "catanTracker_panelCollapsed"
  };

  // ─────────────────────────────────────────────────────────────────────────────
  // SECTION 2: STATE MANAGEMENT
  // ─────────────────────────────────────────────────────────────────────────────

  // Global state - shared across all functions
  let state = null;
  let gameHistory = [];
  let GLOBAL_PROCESSED_MESSAGES = new Set();
  let processedIndexes = new Set();
  let isRescanning = false;
  let root = null;

  function createResourceTracking() {
    const tracking = {};
    RESOURCES.forEach(res => {
      tracking[res] = { starting: 0, rolled: 0, stolen: 0, bankTrade: 0, discarded: 0, total: 0 };
    });
    return tracking;
  }

  function createEmptyResources() {
    return { brick: 0, lumber: 0, wool: 0, grain: 0, ore: 0 };
  }

  function createEmptyDevUsed() {
    const devUsed = {};
    DEV_CARD_TYPES.forEach(type => {
      devUsed[type] = 0;
    });
    return devUsed;
  }

  function createMinimizedState() {
    return {
      dice: false,
      oppHand: false,
      myRes: false,
      devCards: false,
      history: false
    };
  }

function createDefaultState() {
    return {
      myName: "",
      opponentName: "",
      opponentManual: false,
      resources: createEmptyResources(),
      myResources: createEmptyResources(),
      oppTracking: createResourceTracking(),
      myTracking: createResourceTracking(),
      dice: [],
      sevensYou: 0,
      sevensOpp: 0,
      devUsed: createEmptyDevUsed(),
      devPurchased: 0,
      collapsed: false,
      minimized: createMinimizedState(),
      sectionOrder: [],
      gameInProgress: false,
      gameEnded: false,  
      gameSavedAfterWin: false,
      lastWinnerName: "",
      lastWinningPoints: null,
      lastGameStartTime: null,
      startingResourcesCount: 0,
      suppressConfirms: false,
      gameMode: "1v1",
      players: {},
      blindSteals: [],
      nextBlindStealId: 1,
      playerOrder4p: []
    };
  }

  function validateTracking(tracking) {
    if (!tracking || typeof tracking !== 'object') {
      return createResourceTracking();
    }
    RESOURCES.forEach(res => {
      if (!tracking[res] || typeof tracking[res] !== 'object') {
        tracking[res] = { starting: 0, rolled: 0, stolen: 0, bankTrade: 0, discarded: 0, total: 0 };
      } else {
        const defaults = { starting: 0, rolled: 0, stolen: 0, bankTrade: 0, discarded: 0, total: 0 };
        Object.keys(defaults).forEach(key => {
          if (typeof tracking[res][key] !== 'number') {
            tracking[res][key] = defaults[key];
          }
        });
      }
    });
    return tracking;
  }

  function loadState() {
    try {
      const raw = localStorage.getItem(STORAGE_KEYS.state);
      if (!raw) {
        console.log("[Tracker] No saved state found, using defaults");
        return createDefaultState();
      }
      
      const parsed = JSON.parse(raw);
      const base = createDefaultState();
      const merged = Object.assign(base, parsed);
      
      merged.oppTracking = validateTracking(merged.oppTracking);
      merged.myTracking = validateTracking(merged.myTracking);
      
      if (!merged.resources || typeof merged.resources !== 'object') {
        merged.resources = createEmptyResources();
      }
      if (!merged.myResources || typeof merged.myResources !== 'object') {
        merged.myResources = createEmptyResources();
      }
      if (!merged.devUsed || typeof merged.devUsed !== 'object') {
        merged.devUsed = createEmptyDevUsed();
      }
      if (!merged.minimized || typeof merged.minimized !== 'object') {
        merged.minimized = createMinimizedState();
      }
      if (!Array.isArray(merged.dice)) {
        merged.dice = [];
      }
      if (!Array.isArray(merged.sectionOrder)) {
        merged.sectionOrder = [];
      }
      if (merged.gameMode !== "4p" && merged.gameMode !== "1v1") {
        merged.gameMode = "1v1";
      }
      if (!merged.players || typeof merged.players !== "object") {
        merged.players = {};
      }
      if (!Array.isArray(merged.blindSteals)) {
        merged.blindSteals = [];
      }
      if (typeof merged.nextBlindStealId !== "number") {
        merged.nextBlindStealId = 1;
      }
      if (!Array.isArray(merged.playerOrder4p)) {
        merged.playerOrder4p = [];
      }
      if (typeof merged.lastWinnerName !== "string") {
        merged.lastWinnerName = "";
      }
      if (typeof merged.lastWinningPoints !== "number") {
        merged.lastWinningPoints = null;
      }
      if (typeof merged.gameSavedAfterWin !== "boolean") {
        merged.gameSavedAfterWin = false;
      }
      Object.values(merged.players).forEach(p => {
        if (!p || typeof p !== "object") return;
        if (typeof p.unknownGained !== "number") p.unknownGained = 0;
        if (typeof p.unknownLost !== "number") p.unknownLost = 0;
        if (typeof p.sevens !== "number") p.sevens = 0;
        if (typeof p.devBuys !== "number") p.devBuys = 0;
        if (typeof p.devCardsHeld !== "number") p.devCardsHeld = 0;
        if (typeof p.colonistColor !== "string") p.colonistColor = null;
        p.tracking = validateTracking(p.tracking);
        if (!p.resources || typeof p.resources !== "object") p.resources = createEmptyResources();
      });
      
      console.log("[Tracker] State loaded successfully");
      return merged;
    } catch (e) {
      console.error("[Tracker] Error loading state:", e);
      return createDefaultState();
    }
  }

  let saveTimeout = null;
  function saveState() {
    if (saveTimeout) clearTimeout(saveTimeout);
    saveTimeout = setTimeout(() => {
      try {
        localStorage.setItem(STORAGE_KEYS.state, JSON.stringify(state));
      } catch (e) {
        console.error("[Tracker] Failed to save state:", e);
      }
    }, TIMING.saveDebounce);
  }

  function loadGameHistory() {
    try {
      const raw = localStorage.getItem(STORAGE_KEYS.gameHistory);
      return raw ? JSON.parse(raw) : [];
    } catch (e) {
      console.error("[Tracker] Error loading game history:", e);
      return [];
    }
  }

  function saveGameHistory() {
    try {
      localStorage.setItem(STORAGE_KEYS.gameHistory, JSON.stringify(gameHistory));
    } catch (e) {
      console.error("[Tracker] Failed to save game history:", e);
    }
  }

  function loadGlobalProcessedMessages() {
    try {
      const raw = localStorage.getItem(STORAGE_KEYS.processedMessages);
      return raw ? new Set(JSON.parse(raw)) : new Set();
    } catch (e) {
      return new Set();
    }
  }

  function saveGlobalProcessedMessages() {
    try {
      localStorage.setItem(STORAGE_KEYS.processedMessages, JSON.stringify(Array.from(GLOBAL_PROCESSED_MESSAGES)));
    } catch (e) {
      console.error("[Tracker] Failed to save processed messages:", e);
    }
  }

  function markGameWinnerFromLog(text) {
    if (!state) return;
    const winnerMatch = text.match(/^(.+?)\s+won the game/i);
    state.lastWinnerName = winnerMatch ? winnerMatch[1].trim() : "";
    const pointsMatch = text.match(/(\d+)\s+points?/i);
    state.lastWinningPoints = pointsMatch ? parseInt(pointsMatch[1], 10) : null;
  }

  function loadSuppressConfirms() {
    try {
      const raw = localStorage.getItem(STORAGE_KEYS.suppressConfirms);
      if (raw === "true") return true;
      if (raw === "false") return false;
      return null;
    } catch (e) {
      return null;
    }
  }

  function saveSuppressConfirms(enabled) {
    try {
      localStorage.setItem(STORAGE_KEYS.suppressConfirms, enabled ? "true" : "false");
    } catch (e) {
      console.error("[Tracker] Failed to save suppress confirms:", e);
    }
  }

  function loadPanelPosition() {
    try {
      const raw = localStorage.getItem(STORAGE_KEYS.panelPosition);
      if (!raw) return null;
      const parsed = JSON.parse(raw);
      if (!parsed || typeof parsed !== "object") return null;
      if (typeof parsed.left !== "number" || typeof parsed.top !== "number") return null;
      return { left: parsed.left, top: parsed.top };
    } catch (e) {
      return null;
    }
  }

  function savePanelPosition(left, top) {
    try {
      localStorage.setItem(STORAGE_KEYS.panelPosition, JSON.stringify({ left, top }));
    } catch (e) {
      console.error("[Tracker] Failed to save panel position:", e);
    }
  }

  function loadPanelCollapsed() {
    try {
      const raw = localStorage.getItem(STORAGE_KEYS.panelCollapsed);
      if (raw === "true") return true;
      if (raw === "false") return false;
      return null;
    } catch (e) {
      return null;
    }
  }

  function savePanelCollapsed(collapsed) {
    try {
      localStorage.setItem(STORAGE_KEYS.panelCollapsed, collapsed ? "true" : "false");
    } catch (e) {
      console.error("[Tracker] Failed to save panel collapsed state:", e);
    }
  }

  function getClampedPanelPosition(left, top) {
    if (!root) return { left, top };
    const rect = root.getBoundingClientRect();
    const width = rect.width || root.offsetWidth || 360;
    const height = rect.height || root.offsetHeight || 240;
    const minVisible = 36;
    const minLeft = minVisible - width;
    const minTop = 0;
    const maxLeft = Math.max(minVisible, window.innerWidth - minVisible);
    const maxTop = Math.max(0, window.innerHeight - minVisible);
    return {
      left: Math.min(maxLeft, Math.max(minLeft, left)),
      top: Math.min(maxTop, Math.max(minTop, top))
    };
  }

  function applyPanelPosition(position) {
    if (!root || !position) return;
    const clamped = getClampedPanelPosition(position.left, position.top);
    root.style.left = `${clamped.left}px`;
    root.style.top = `${clamped.top}px`;
    root.style.right = "auto";
    savePanelPosition(clamped.left, clamped.top);
  }

  // ─────────────────────────────────────────────────────────────────────────────
  // SECTION 3: CSS STYLES
  // ─────────────────────────────────────────────────────────────────────────────

  function getTrackerStyles() {
    return `
      #${TRACKER_ID} {
        position: fixed;
        top: 60px;
        right: 10px;
        width: 360px;
        min-width: 300px;
        max-width: 520px;
        max-height: 80vh;
        overflow: hidden;
        resize: both;
        box-sizing: border-box;
        background: linear-gradient(180deg, #1D82D1, #2C99E5);
        border: 2px solid #0E6FB9;
        border-radius: 16px;
        padding: 0;
        color: #ffffff;
        font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', system-ui, sans-serif;
        font-size: 13px;
        line-height: 1.4;
        box-shadow: 0 12px 40px rgba(10, 96, 160, 0.45);
        z-index: 99999999;
        cursor: move;
        display: flex;
        flex-direction: column;
      }
      
      #${TRACKER_ID} * {
        box-sizing: border-box;
      }
      
      #${TRACKER_ID} .tracker-header {
        margin: 0;
        padding: 8px 12px;
        display: flex;
        justify-content: space-between;
        align-items: center;
        background: linear-gradient(90deg, #0A60A0, #0E6FB9);
        color: #ffffff;
        font-weight: 700;
        font-size: 15px;
        border-radius: 14px 14px 0 0;
        border-bottom: 2px solid rgba(255, 255, 255, 0.2);
        box-shadow: 0 2px 8px rgba(0, 0, 0, 0.2);
        flex-shrink: 0;
        cursor: move;
      }
      
      #${TRACKER_ID} .tracker-header-buttons {
        display: flex;
        gap: 6px;
        align-items: center;
      }
      #${TRACKER_ID} #top-game-mode-toggle {
        font-size: 10px;
        font-weight: 800;
        min-width: 34px;
        padding: 4px 6px;
        letter-spacing: -0.02em;
        line-height: 1.2;
      }
      
      #${TRACKER_ID} .tracker-body-wrapper {
        overflow-y: auto;
        overflow-x: hidden;
        flex: 1;
        padding: 12px;
        cursor: auto;
      }
      
      #${TRACKER_ID} .tracker-footer {
        padding: 6px 12px;
        text-align: center;
        font-size: 10px;
        background: rgba(0, 0, 0, 0.15);
        border-top: 1px solid rgba(255, 255, 255, 0.1);
        border-radius: 0 0 14px 14px;
        flex-shrink: 0;
      }
      
      #${TRACKER_ID} .tracker-footer a {
        color: #ffffff;
        text-decoration: none;
        font-weight: 600;
        transition: opacity 0.2s;
        cursor: pointer;
      }
      
      #${TRACKER_ID} .tracker-footer a:hover {
        opacity: 0.8;
        text-decoration: underline;
      }
      
      #${TRACKER_ID} button {
        padding: 4px 10px;
        font-size: 12px;
        font-weight: 600;
        font-family: inherit;
        border-radius: 6px;
        border: 1px solid rgba(0, 0, 0, 0.1);
        background: linear-gradient(135deg, #f97316, #ea580c);
        color: #ffffff;
        cursor: pointer;
        transition: all 0.15s ease;
        box-shadow: 0 2px 4px rgba(0, 0, 0, 0.1);
        line-height: 1.4;
      }
      
      #${TRACKER_ID} button:hover {
        transform: translateY(-1px);
        box-shadow: 0 4px 8px rgba(0, 0, 0, 0.15);
        filter: brightness(1.1);
      }
      
      #${TRACKER_ID} button:active {
        transform: scale(0.96);
      }
      
      #${TRACKER_ID} #rescan-log-btn {
        background: linear-gradient(135deg, #f97316, #ea580c);
        font-weight: 700;
      }
      
      #${TRACKER_ID} .lock-btn {
        background: linear-gradient(135deg, #fbbf24, #f59e0b);
      }
      
      #${TRACKER_ID} .lock-btn.locked {
        background: linear-gradient(135deg, #10b981, #059669);
      }
      
      #${TRACKER_ID} input[type="text"],
      #${TRACKER_ID} input:not([type]) {
        color: #1f2937;
        background: #ffffff;
        border: 2px solid rgba(14, 111, 185, 0.3);
        padding: 6px 8px;
        border-radius: 8px;
        width: 100%;
        box-sizing: border-box;
        margin: 4px 0;
        font-size: 13px;
        font-family: inherit;
        transition: border-color 0.2s;
        cursor: text;
      }
      
      #${TRACKER_ID} input:focus {
        outline: none;
        border-color: #0E6FB9;
      }
      
      #${TRACKER_ID} input[type="checkbox"] {
        width: auto;
        margin: 0;
        cursor: pointer;
      }
      
      #${TRACKER_ID} .section {
        background: rgba(255, 255, 255, 0.15);
        backdrop-filter: blur(10px);
        border: 1px solid rgba(255, 255, 255, 0.25);
        border-radius: 12px;
        padding: 10px;
        margin: 10px 0;
        color: #ffffff;
        box-shadow: 0 4px 12px rgba(0, 0, 0, 0.1);
        overflow: visible;
        transition: all 0.2s ease;
        position: relative;
      }
      
      #${TRACKER_ID} .section.dragging {
        opacity: 0.5;
        transform: scale(0.98);
      }
      
      #${TRACKER_ID} .section.drag-over {
        border-color: #3b82f6;
        box-shadow: 0 0 20px rgba(59, 130, 246, 0.5);
        transform: translateY(-2px);
      }
      
      #${TRACKER_ID} .section-header {
        display: flex;
        justify-content: space-between;
        align-items: center;
        margin-bottom: 8px;
        padding-bottom: 6px;
        border-bottom: 1px solid rgba(255, 255, 255, 0.2);
        font-weight: 700;
        font-size: 13px;
        cursor: grab;
        user-select: none;
      }
      
      #${TRACKER_ID} .section-header:active {
        cursor: grabbing;
      }
      
      #${TRACKER_ID} .section-header::before {
        content: '⋮⋮';
        margin-right: 8px;
        opacity: 0.6;
        font-weight: 700;
        font-size: 16px;
        color: rgba(255, 255, 255, 0.8);
      }
      
      #${TRACKER_ID} .section-header-buttons {
        display: flex;
        gap: 4px;
      }
      
      #${TRACKER_ID} .section-header-buttons button {
        padding: 2px 8px;
        font-size: 11px;
      }
      
      #${TRACKER_ID} .section-content {
        transition: max-height 0.3s ease, opacity 0.3s ease;
        overflow: visible;
        position: relative;
      }
      
      #${TRACKER_ID} .section-content.minimized {
        max-height: 0 !important;
        opacity: 0;
        margin: 0;
        padding: 0;
        overflow: hidden;
      }
      
      #${TRACKER_ID} .condensed-stats {
        display: none;
        padding: 6px 8px;
        background: rgba(0, 0, 0, 0.15);
        border-radius: 8px;
        margin-top: 6px;
      }
      
      #${TRACKER_ID} .section-content.minimized ~ .condensed-stats {
        display: block;
      }
      
      #${TRACKER_ID} .condensed-row {
        display: flex;
        justify-content: space-around;
        align-items: center;
        gap: 4px;
        flex-wrap: nowrap;
      }
      
      #${TRACKER_ID} .condensed-item {
        display: flex;
        align-items: center;
        gap: 3px;
        min-width: 40px;
        padding: 2px 4px;
      }
      
      #${TRACKER_ID} .condensed-emoji {
        font-size: 16px;
        line-height: 16px;
      }
      
      #${TRACKER_ID} .condensed-value {
        font-size: 12px;
        font-weight: 700;
        color: #ffffff;
      }
      
      #${TRACKER_ID} .res-row {
        display: flex;
        align-items: center;
        gap: 8px;
        padding: 8px 10px;
        border-radius: 10px;
        background: rgba(0, 0, 0, 0.15);
        color: #ffffff;
        margin: 6px 0;
        position: relative;
        box-shadow: 0 2px 6px rgba(0, 0, 0, 0.1);
      }
      
      #${TRACKER_ID} .res-name {
        width: 75px;
        font-weight: 700;
        display: flex;
        gap: 5px;
        align-items: center;
        cursor: help;
        font-size: 13px;
        color: #ffffff;
      }
      
      #${TRACKER_ID} .res-count {
        width: 28px;
        text-align: right;
        font-weight: 700;
        font-size: 14px;
        color: #ffffff;
      }
      
      #${TRACKER_ID} .res-bar {
        flex: 1;
        height: 10px;
        background: rgba(0, 0, 0, 0.3);
        border-radius: 999px;
        overflow: hidden;
        border: 1px solid rgba(255, 255, 255, 0.1);
      }
      
      #${TRACKER_ID} .bar-inner {
        height: 100%;
        border-radius: 999px;
        transition: width 0.25s ease;
      }
      
      #${TRACKER_ID} .bar-brick { background: linear-gradient(90deg, #ef4444, #dc2626); }
      #${TRACKER_ID} .bar-lumber { background: linear-gradient(90deg, #22c55e, #16a34a); }
      #${TRACKER_ID} .bar-wool { background: linear-gradient(90deg, #a3e635, #84cc16); }
      #${TRACKER_ID} .bar-grain { background: linear-gradient(90deg, #fbbf24, #f59e0b); }
      #${TRACKER_ID} .bar-ore { background: linear-gradient(90deg, #9ca3af, #6b7280); }
      
      #${TRACKER_ID} .res-buttons {
        display: flex;
        gap: 3px;
      }
      
      #${TRACKER_ID} .res-buttons button {
        padding: 2px 8px;
        font-size: 11px;
        min-width: 24px;
      }
      
      #${TRACKER_ID} .tooltip {
        position: absolute;
        left: 50%;
        bottom: calc(100% + 12px);
        transform: translateX(-50%);
        background: rgba(17, 24, 39, 0.98);
        color: #ffffff;
        padding: 12px 14px;
        border-radius: 10px;
        font-size: 12px;
        line-height: 1.7;
        white-space: nowrap;
        pointer-events: none;
        opacity: 0;
        transition: opacity 0.2s ease;
        z-index: 999999999;
        box-shadow: 0 8px 24px rgba(0, 0, 0, 0.8);
        border: 2px solid rgba(255, 255, 255, 0.2);
        min-width: 200px;
        max-width: 300px;
      }
      
      #${TRACKER_ID} .tooltip::after {
        content: '';
        position: absolute;
        top: 100%;
        left: 50%;
        transform: translateX(-50%);
        border: 8px solid transparent;
        border-top-color: rgba(17, 24, 39, 0.98);
      }
      
      #${TRACKER_ID} .res-row:hover .tooltip {
        opacity: 1;
      }
      
      #${TRACKER_ID} .tooltip-line {
        display: flex;
        justify-content: space-between;
        gap: 16px;
        margin: 3px 0;
        padding: 2px 0;
      }
      
      #${TRACKER_ID} .tooltip-label {
        color: #9ca3af;
        font-weight: 500;
      }
      
      #${TRACKER_ID} .tooltip-value {
        font-weight: 700;
        color: #ffffff;
        min-width: 20px;
        text-align: right;
      }
      
      #${TRACKER_ID} .tooltip-total {
        margin-top: 6px;
        padding-top: 6px;
        border-top: 1px solid rgba(255, 255, 255, 0.25);
      }
      
      #${TRACKER_ID} #catan-collapsed-bar {
        display: none;
        margin-top: 8px;
        padding: 8px 12px;
        border-radius: 12px;
        justify-content: space-between;
        align-items: center;
        gap: 12px;
        font-size: 12px;
        font-weight: 700;
        background: linear-gradient(90deg, #0A60A0, #0E6FB9);
        border: 1px solid rgba(255, 255, 255, 0.3);
        color: #ffffff;
      }
      #${TRACKER_ID} #catan-collapsed-bar.collapsed-4p-mode {
        flex-direction: column;
        align-items: stretch;
        justify-content: flex-start;
        gap: 10px;
      }
      #${TRACKER_ID} #catan-collapsed-bar.collapsed-4p-mode #collapsed-dev-wrap {
        align-self: flex-end;
      }
      #${TRACKER_ID} #catan-collapsed-bar.collapsed-4p-mode #collapsed-dice-wrap {
        align-self: flex-end;
      }
      #${TRACKER_ID} #collapsed-opp-1v1 {
        display: flex;
        flex-wrap: wrap;
        align-items: center;
        gap: 12px;
        flex: 1;
      }
      #${TRACKER_ID} #collapsed-4p-hands {
        display: none;
        flex-direction: column;
        gap: 8px;
        width: 100%;
      }
      #${TRACKER_ID} #collapsed-4p-hands.collapsed-4p-visible {
        display: flex;
      }
      #${TRACKER_ID} .collapsed-4p-row {
        display: flex;
        flex-wrap: wrap;
        align-items: center;
        gap: 8px 10px;
        width: 100%;
        padding: 4px 0;
        border-bottom: 1px solid rgba(255, 255, 255, 0.12);
      }
      #${TRACKER_ID} .collapsed-4p-row:last-child {
        border-bottom: none;
        padding-bottom: 0;
      }
      #${TRACKER_ID} .collapsed-4p-name {
        font-size: 10px;
        font-weight: 800;
        min-width: 56px;
        max-width: 92px;
        overflow: hidden;
        text-overflow: ellipsis;
        white-space: nowrap;
        flex-shrink: 0;
      }
      #${TRACKER_ID} .collapsed-4p-totals {
        font-size: 8px;
        font-weight: 800;
        color: #e0f2fe;
        white-space: nowrap;
        flex-shrink: 0;
        opacity: 0.95;
      }
      #${TRACKER_ID} .collapsed-4p-res-strip {
        display: flex;
        flex-wrap: wrap;
        align-items: center;
        gap: 8px;
        flex: 1;
      }
      #${TRACKER_ID} .collapsed-res-tiny {
        min-width: 26px;
      }
      #${TRACKER_ID} .collapsed-res-tiny .res-emoji {
        font-size: 16px;
        line-height: 16px;
      }
      #${TRACKER_ID} .collapsed-res-tiny .collapsed-count {
        font-size: 10px;
        margin-top: 1px;
      }
      #${TRACKER_ID} .collapsed-4p-q {
        font-size: 8px;
        font-weight: 700;
        color: #fbbf24;
        opacity: 0.95;
        white-space: nowrap;
      }
      #${TRACKER_ID} #condensed-opp-stats-wrap.condensed-4p-mode #condensed-opp-1v1 {
        display: none !important;
      }
      #${TRACKER_ID} #condensed-opp-4p {
        display: none;
        flex-direction: column;
        gap: 4px;
        width: 100%;
      }
      #${TRACKER_ID} #condensed-opp-4p.condensed-4p-visible {
        display: flex;
      }
      #${TRACKER_ID} .condensed-4p-block {
        display: flex;
        flex-wrap: wrap;
        align-items: center;
        gap: 6px;
        width: 100%;
        padding: 4px 0;
        border-bottom: 1px solid rgba(255, 255, 255, 0.1);
      }
      #${TRACKER_ID} .condensed-4p-block:last-child {
        border-bottom: none;
      }
      #${TRACKER_ID} .condensed-4p-block .condensed-4p-name {
        font-size: 9px;
        font-weight: 700;
        min-width: 52px;
        max-width: 80px;
        overflow: hidden;
        text-overflow: ellipsis;
        white-space: nowrap;
      }
      #${TRACKER_ID} .condensed-4p-handtot {
        font-size: 7px;
        font-weight: 800;
        color: #bae6fd;
        white-space: nowrap;
        flex-shrink: 0;
      }
      #${TRACKER_ID} .condensed-4p-block .condensed-row-inner {
        display: flex;
        flex-wrap: wrap;
        align-items: center;
        gap: 4px;
        flex: 1;
        justify-content: flex-start;
      }
      
      #${TRACKER_ID} .collapsed-res {
        display: flex;
        flex-direction: column;
        align-items: center;
        min-width: 30px;
      }
      
      #${TRACKER_ID} .collapsed-res .res-emoji {
        font-size: 22px;
        line-height: 22px;
      }
      
      #${TRACKER_ID} .collapsed-count {
        font-size: 14px;
        font-weight: 800;
        margin-top: 3px;
        color: #ffffff;
      }
      
      #${TRACKER_ID} #dev-card-tooltip {
        position: fixed;
        background: linear-gradient(180deg, #1D82D1, #2C99E5);
        border: 2px solid #0E6FB9;
        border-radius: 12px;
        padding: 12px 16px;
        box-shadow: 0 8px 24px rgba(10, 96, 160, 0.6);
        min-width: 220px;
        color: #ffffff;
        opacity: 0;
        pointer-events: none;
        transition: opacity 0.2s ease;
        z-index: 9999999999;
      }
      
      #${TRACKER_ID} #dev-card-tooltip::after {
        content: '';
        position: absolute;
        bottom: -10px;
        right: 20px;
        border: 8px solid transparent;
        border-top-color: #0E6FB9;
      }
      
      #${TRACKER_ID} #show-dev-popup:hover + #dev-card-tooltip,
      #${TRACKER_ID} #dev-card-tooltip:hover {
        opacity: 1;
        pointer-events: auto;
      }
      
      #${TRACKER_ID} #dev-card-tooltip h4 {
        margin: 0 0 8px 0;
        font-size: 13px;
        font-weight: 700;
        text-align: center;
        padding-bottom: 6px;
        border-bottom: 1px solid rgba(255, 255, 255, 0.2);
      }
      #${TRACKER_ID} #dice-collapsed-tooltip {
        position: fixed;
        background: linear-gradient(180deg, #1D82D1, #2C99E5);
        border: 2px solid #0E6FB9;
        border-radius: 12px;
        padding: 12px 14px;
        box-shadow: 0 8px 24px rgba(10, 96, 160, 0.6);
        min-width: 250px;
        color: #ffffff;
        opacity: 0;
        pointer-events: none;
        transition: opacity 0.2s ease;
        z-index: 9999999999;
      }
      #${TRACKER_ID} #dice-collapsed-tooltip::after {
        content: '';
        position: absolute;
        bottom: -10px;
        right: 20px;
        border: 8px solid transparent;
        border-top-color: #0E6FB9;
      }
      #${TRACKER_ID} #show-dice-popup:hover + #dice-collapsed-tooltip,
      #${TRACKER_ID} #dice-collapsed-tooltip:hover {
        opacity: 1;
        pointer-events: auto;
      }
      #${TRACKER_ID} #dice-collapsed-tooltip h4 {
        margin: 0 0 8px 0;
        font-size: 13px;
        font-weight: 700;
        text-align: center;
        padding-bottom: 6px;
        border-bottom: 1px solid rgba(255, 255, 255, 0.2);
      }
      
      #${TRACKER_ID} .dev-tooltip-item {
        display: flex;
        justify-content: space-between;
        align-items: center;
        padding: 4px 6px;
        margin: 4px 0;
        background: rgba(255, 255, 255, 0.1);
        border-radius: 6px;
        font-size: 11px;
      }
      
      #${TRACKER_ID} .dev-tooltip-item-label {
        display: flex;
        align-items: center;
        gap: 6px;
        font-weight: 600;
      }
      
      #${TRACKER_ID} .dev-tooltip-item-value {
        font-weight: 700;
        font-size: 12px;
      }
      
      #${TRACKER_ID} .user-setup-section {
        display: flex;
        flex-direction: column;
        gap: 8px;
      }
      
      #${TRACKER_ID} .opponent-display {
        padding: 8px 10px;
        background: rgba(255, 255, 255, 0.1);
        border-radius: 8px;
        display: flex;
        justify-content: space-between;
        align-items: center;
        font-size: 13px;
      }
      
      #${TRACKER_ID} .opponent-display button {
        padding: 3px 10px;
        font-size: 11px;
      }
      
      #${TRACKER_ID} .inline-btn-group {
        display: flex;
        gap: 6px;
        margin-top: 6px;
      }
      
      #${TRACKER_ID} .inline-btn-group button {
        flex: 1;
      }
      
      #${TRACKER_ID} .history-item {
        background: rgba(0, 0, 0, 0.2);
        border-radius: 10px;
        padding: 12px;
        margin: 8px 0;
        border: 1px solid rgba(255, 255, 255, 0.1);
        cursor: pointer;
        transition: all 0.2s ease;
        position: relative;
      }
      
      #${TRACKER_ID} .history-item:hover {
        background: rgba(0, 0, 0, 0.3);
        border-color: rgba(255, 255, 255, 0.2);
        transform: translateX(4px);
      }
      
      #${TRACKER_ID} .history-item.locked {
        border-color: #fbbf24;
        box-shadow: 0 0 10px rgba(251, 191, 36, 0.3);
      }
      
      #${TRACKER_ID} .history-item.locked::before {
        content: '🔒';
        position: absolute;
        top: 8px;
        right: 8px;
        font-size: 16px;
        filter: drop-shadow(0 2px 4px rgba(0, 0, 0, 0.3));
      }
      #${TRACKER_ID} .history-item.history-win {
        background: rgba(16, 185, 129, 0.22);
        border-color: rgba(16, 185, 129, 0.55);
      }
      #${TRACKER_ID} .history-item.history-win:hover {
        background: rgba(16, 185, 129, 0.3);
        border-color: rgba(52, 211, 153, 0.75);
      }
      #${TRACKER_ID} .history-item.history-loss {
        background: rgba(239, 68, 68, 0.22);
        border-color: rgba(239, 68, 68, 0.55);
      }
      #${TRACKER_ID} .history-item.history-loss:hover {
        background: rgba(239, 68, 68, 0.3);
        border-color: rgba(248, 113, 113, 0.75);
      }
      
      #${TRACKER_ID} .history-header {
        display: flex;
        justify-content: space-between;
        align-items: center;
        margin-bottom: 6px;
        font-weight: 700;
        font-size: 13px;
      }
      
      #${TRACKER_ID} .history-date {
        font-size: 11px;
        opacity: 0.7;
      }
      
      #${TRACKER_ID} .history-stats {
        display: grid;
        grid-template-columns: 1fr 1fr;
        gap: 6px;
        font-size: 11px;
        margin-top: 6px;
      }
      
      #${TRACKER_ID} .history-stat {
        display: flex;
        justify-content: space-between;
        padding: 4px 6px;
        background: rgba(255, 255, 255, 0.05);
        border-radius: 6px;
      }
      
      #${TRACKER_ID} .history-buttons {
        display: flex;
        gap: 6px;
        margin-top: 8px;
      }
      
      #${TRACKER_ID} .history-buttons button {
        flex: 1;
        padding: 4px 8px;
        font-size: 10px;
      }
      
      #${TRACKER_ID} .no-history {
        text-align: center;
        padding: 20px;
        opacity: 0.6;
        font-style: italic;
      }
      
      #${TRACKER_ID} .player-hand-block {
        margin-bottom: 14px;
        padding-bottom: 10px;
        border-bottom: 1px solid rgba(255, 255, 255, 0.12);
      }
      #${TRACKER_ID} .player-hand-block:last-child {
        border-bottom: none;
        margin-bottom: 0;
      }
      #${TRACKER_ID} .player-hand-title {
        display: flex;
        justify-content: space-between;
        align-items: center;
        gap: 8px;
        font-weight: 700;
        font-size: 12px;
        margin-bottom: 6px;
        color: #e5e7eb;
      }
      #${TRACKER_ID} .player-hand-title .player-you-suffix {
        font-weight: 600;
        opacity: 0.85;
      }
      #${TRACKER_ID} .player-hand-title-center {
        flex: 1;
        min-width: 0;
      }
      #${TRACKER_ID} .order-ctrl-full {
        display: inline-flex;
        flex-direction: column;
        gap: 1px;
        flex-shrink: 0;
      }
      #${TRACKER_ID} .order-btn-full {
        font-size: 9px;
        line-height: 1;
        padding: 1px 5px;
        min-height: 0;
        border-radius: 4px;
        border: 1px solid rgba(255, 255, 255, 0.25);
        background: rgba(0, 0, 0, 0.25);
        color: #e5e7eb;
        cursor: pointer;
      }
      #${TRACKER_ID} .order-btn-full:hover {
        background: rgba(255, 255, 255, 0.12);
      }
      #${TRACKER_ID} .order-ctrl-compact {
        display: inline-flex;
        flex-direction: column;
        gap: 0;
        flex-shrink: 0;
        margin-right: 2px;
      }
      #${TRACKER_ID} .order-btn-compact {
        font-size: 7px;
        line-height: 1;
        padding: 0 3px;
        min-height: 0;
        border-radius: 3px;
        border: 1px solid rgba(255, 255, 255, 0.2);
        background: rgba(0, 0, 0, 0.2);
        color: #e5e7eb;
        cursor: pointer;
      }
      #${TRACKER_ID} .order-btn-compact:hover {
        background: rgba(255, 255, 255, 0.1);
      }
      #${TRACKER_ID} .unknown-tags {
        font-size: 10px;
        font-weight: 600;
        opacity: 0.85;
        color: #fbbf24;
      }
      #${TRACKER_ID} .hand-estimate {
        font-size: 10px;
        opacity: 0.75;
        margin-bottom: 6px;
      }
      #${TRACKER_ID} .resolve-unknown-row {
        display: flex;
        flex-wrap: wrap;
        gap: 4px;
        align-items: center;
        margin-top: 6px;
        font-size: 10px;
      }
      #${TRACKER_ID} .resolve-unknown-row button {
        padding: 2px 6px;
        font-size: 10px;
        min-width: auto;
      }
      #${TRACKER_ID} #blind-steals-panel {
        display: none;
        margin-top: 10px;
        padding: 8px;
        background: rgba(0, 0, 0, 0.2);
        border-radius: 8px;
        font-size: 11px;
        line-height: 1.5;
      }
      #${TRACKER_ID} .blind-steal-item {
        margin-top: 8px;
        padding-top: 8px;
        border-top: 1px solid rgba(255, 255, 255, 0.1);
      }
      #${TRACKER_ID} .poss-chips {
        display: flex;
        flex-wrap: wrap;
        gap: 4px;
        margin-top: 4px;
      }
      #${TRACKER_ID} .poss-chips label {
        display: flex;
        align-items: center;
        gap: 2px;
        cursor: pointer;
        font-size: 10px;
        opacity: 0.9;
      }
      #${TRACKER_ID} #game-mode-select {
        width: 100%;
        margin-top: 4px;
        padding: 4px 6px;
        font-size: 11px;
        border-radius: 6px;
        border: 1px solid rgba(255, 255, 255, 0.25);
        background: rgba(0, 0, 0, 0.25);
        color: #fff;
      }
      
      #${TRACKER_ID} #info-popup-overlay {
        display: none;
      }
      
      #${TRACKER_ID} #info-popup-overlay.show {
        display: block;
      }
      
      #${TRACKER_ID} #info-popup {
        background: transparent;
        border: none;
        border-radius: 0;
        padding: 12px;
        box-shadow: none;
        color: #ffffff;
      }
      
      #${TRACKER_ID} #info-popup h2 {
        margin: 0 0 16px 0;
        font-size: 18px;
        font-weight: 700;
        text-align: center;
        padding-bottom: 12px;
        border-bottom: 2px solid rgba(255, 255, 255, 0.2);
      }
      
      #${TRACKER_ID} #info-popup h3 {
        margin: 16px 0 8px 0;
        font-size: 14px;
        font-weight: 700;
        color: #fbbf24;
      }
      
      #${TRACKER_ID} #info-popup p {
        margin: 8px 0;
        line-height: 1.6;
        font-size: 12px;
      }
      
      #${TRACKER_ID} #info-popup ul {
        margin: 8px 0;
        padding-left: 20px;
        line-height: 1.7;
        font-size: 12px;
        list-style: disc;
      }
      
      #${TRACKER_ID} #info-popup li {
        margin: 4px 0;
      }
      
      #${TRACKER_ID} #info-popup strong {
        color: #fbbf24;
        font-weight: 700;
      }
      
      #${TRACKER_ID} #info-popup-close {
        width: 100%;
        margin-top: 16px;
        padding: 8px;
        font-size: 13px;
        font-weight: 700;
      }
    `;
  }

  function injectTrackerStyles() {
    const existingStyle = document.getElementById('catan-tracker-styles');
    if (existingStyle) {
      existingStyle.remove();
    }
    
    const styleElement = document.createElement('style');
    styleElement.id = 'catan-tracker-styles';
    styleElement.textContent = getTrackerStyles();
    document.head.appendChild(styleElement);
    
    console.log("[Tracker] Styles injected");
  }

  // ─────────────────────────────────────────────────────────────────────────────
  // SECTION 4: HTML TEMPLATES
  // ─────────────────────────────────────────────────────────────────────────────

  function buildResourceRowHTML(resourceKey, icon, owner) {
    const displayName = resourceKey.charAt(0).toUpperCase() + resourceKey.slice(1);
    
    return `
      <div class="res-row">
        <div class="res-name">
          <span>${icon}</span>
          <span>${displayName}</span>
        </div>
        <div class="res-count" id="${owner}-${resourceKey}">0</div>
        <div class="res-bar">
          <div class="bar-inner bar-${resourceKey}" id="${owner}-bar-${resourceKey}" style="width:0"></div>
        </div>
        <div class="res-buttons">
          <button data-owner="${owner}" data-res="${resourceKey}" data-delta="-1">−</button>
          <button data-owner="${owner}" data-res="${resourceKey}" data-delta="1">+</button>
        </div>
        <div class="tooltip" id="${owner}-${resourceKey}-tooltip">
          <div class="tooltip-line">
            <span class="tooltip-label">Starting:</span>
            <span class="tooltip-value" id="${owner}-${resourceKey}-starting">0</span>
          </div>
          <div class="tooltip-line">
            <span class="tooltip-label">Rolled:</span>
            <span class="tooltip-value" id="${owner}-${resourceKey}-rolled">0</span>
          </div>
          <div class="tooltip-line">
            <span class="tooltip-label">Stolen:</span>
            <span class="tooltip-value" id="${owner}-${resourceKey}-stolen">0</span>
          </div>
          <div class="tooltip-line">
            <span class="tooltip-label">Bank Trade:</span>
            <span class="tooltip-value" id="${owner}-${resourceKey}-trade">0</span>
          </div>
          <div class="tooltip-line">
            <span class="tooltip-label">Discarded:</span>
            <span class="tooltip-value" id="${owner}-${resourceKey}-discarded">0</span>
          </div>
          <div class="tooltip-line tooltip-total">
            <span class="tooltip-label">Total Gained:</span>
            <span class="tooltip-value" id="${owner}-${resourceKey}-total">0</span>
          </div>
        </div>
      </div>
    `;
  }

  function buildTrackerHTML() {
    const resourceRows = (owner) => RESOURCES.map(res => 
      buildResourceRowHTML(res, RESOURCE_ICONS[res], owner)
    ).join('');
    
    const condensedItems = (owner) => RESOURCES.map(res => `
      <div class="condensed-item">
        <span class="condensed-emoji">${RESOURCE_ICONS[res]}</span>
        <span class="condensed-value" id="${owner}-${res}-condensed">0</span>
      </div>
    `).join('');

    const devCardRows = DEV_CARD_TYPES.map(type => {
      const key = DEV_CARD_KEYS[type];
      const icon = DEV_CARD_ICONS[type];
      const total = DEV_CARD_TOTALS[type];
      return `
        <div style="display:flex;justify-content:space-between;align-items:center;">
          <span>${icon} ${type}:</span>
          <span>
            <strong><span id="dev-${key}">0</span></strong><span style="opacity:0.7;">/${total}</span>
          </span>
        </div>
      `;
    }).join('');

    const devCondensedItems = DEV_CARD_TYPES.map(type => {
      const key = DEV_CARD_KEYS[type];
      const icon = DEV_CARD_ICONS[type];
      const total = DEV_CARD_TOTALS[type];
      return `
        <div class="condensed-item">
          <span class="condensed-emoji">${icon}</span>
          <span class="condensed-value">
            <span id="dev-${key}-condensed">0</span><span style="opacity:0.6;font-size:10px;">/${total}</span>
          </span>
        </div>
      `;
    }).join('');

    const devTooltipItems = DEV_CARD_TYPES.map(type => {
      const key = DEV_CARD_KEYS[type];
      const icon = DEV_CARD_ICONS[type];
      const shortName = type === "Road Building" ? "Road" : 
                        type === "Year of Plenty" ? "Plenty" : 
                        type === "Victory Point" ? "VP" : type;
      const total = DEV_CARD_TOTALS[type];
      return `
        <div class="dev-tooltip-item">
          <span class="dev-tooltip-item-label">
            <span>${icon}</span>
            <span>${shortName}</span>
          </span>
          <span class="dev-tooltip-item-value">
            <span id="tooltip-dev-${key}">0</span>/${total}
          </span>
        </div>
      `;
    }).join('');

    return `
      <h1 class="tracker-header">
        <span>🎲 Catan Tracker</span>
        <div class="tracker-header-buttons">
          <button id="top-new-game" title="New Game">New</button>
          <button type="button" id="top-game-mode-toggle" title="Switch game mode">1v1</button>
          <button id="catan-info-toggle" title="Guide">?</button>
          <button id="catan-collapse-toggle" title="Collapse">–</button>
        </div>
      </h1>
      
      <div id="catan-collapsed-bar">
        <div id="collapsed-4p-hands" aria-hidden="true"></div>
        <div id="collapsed-opp-1v1">
        ${RESOURCES.map(res => `
          <div class="collapsed-res">
            <span class="res-emoji">${RESOURCE_ICONS[res]}</span>
            <span class="collapsed-count" id="small-${res}">0</span>
          </div>
        `).join('')}
        </div>
        <div id="collapsed-dice-wrap" style="position:relative;flex-shrink:0;">
          <button id="show-dice-popup" title="Dice Stats" style="padding:4px 8px;font-size:16px;min-width:auto;background:rgba(255,255,255,0.2);border:1px solid rgba(255,255,255,0.3);">🎲</button>
          <div id="dice-collapsed-tooltip">
            <h4>🎲 Dice Stats</h4>
            <div id="dice-collapsed-tooltip-content">No rolls yet</div>
          </div>
        </div>
        <div id="collapsed-dev-wrap" style="position:relative;flex-shrink:0;">
          <button id="show-dev-popup" title="Dev Cards" style="padding:4px 8px;font-size:16px;min-width:auto;background:rgba(255,255,255,0.2);border:1px solid rgba(255,255,255,0.3);margin-left:8px;">🃏</button>
          <div id="dev-card-tooltip">
            <h4>🃏 Dev Cards</h4>
            ${devTooltipItems}
            <div class="tooltip-total">
              📦 Purchased: <span id="tooltip-dev-purchased">0</span>/${TOTAL_DEV_CARDS}
            </div>
          </div>
        </div>
      </div>
      
      <div class="tracker-body-wrapper">
        <div id="catan-body">
          <!-- Dice Stats Section -->
          <div class="section" data-section-type="dice">
            <div class="section-header">
              <strong>🎲 Dice Stats</strong>
              <div class="section-header-buttons">
                <button id="dice-minimize">−</button>
                <button id="dice-clear">Clear</button>
              </div>
            </div>
            <div class="section-content" id="dice-content">
              <div id="dice-stats">No rolls yet</div>
              <div style="margin-top:8px; padding-top:8px; border-top:1px solid rgba(255,255,255,0.2);">
                <div id="sevens-1v1-line">
                  <strong>7s Rolled:</strong> You: <span id="sev-you">0</span> | Opponent: <span id="sev-opp">0</span>
                </div>
                <div id="sevens-4p-wrap" style="display:none;margin-top:6px;font-size:11px;line-height:1.65;">
                  <strong>7s (each player):</strong><br/>
                  <span id="sevens-4p-line">—</span>
                </div>
              </div>
            </div>
            <div class="condensed-stats">
              <div class="condensed-row">
                <div class="condensed-item">
                  <span class="condensed-emoji">🎲</span>
                  <span class="condensed-value" id="dice-total-condensed">0</span>
                </div>
                <div class="condensed-item">
                  <span class="condensed-emoji">7️⃣</span>
                  <span class="condensed-value">
                    <span id="sev-you-condensed">0</span>/<span id="sev-opp-condensed">0</span>
                  </span>
                </div>
              </div>
            </div>
          </div>
          
          <!-- Opponent's Hand Section -->
          <div class="section" data-section-type="opponent">
            <div class="section-header">
              <strong id="opponent-section-title">👤 Opponent's Hand</strong>
              <div class="section-header-buttons">
                <button id="opphand-minimize">−</button>
                <button id="hand-clear">Clear</button>
              </div>
            </div>
            <div class="section-content" id="opphand-content">
              <div id="opponent-single-mode">
                ${resourceRows("opp")}
              </div>
              <div id="opponent-multi-mode" style="display:none;"></div>
              <div id="blind-steals-panel">
                <div style="font-weight:700;margin-bottom:4px;">🕵️ Hidden robber steals</div>
                <div style="font-size:10px;opacity:0.8;margin-bottom:6px;">When the log does not show the card, we track <strong>?</strong> on thief/victim. Possibilities default to resource types the victim actually had when the steal was logged. If someone spends a resource we showed as 0, we try to resolve a matching hidden steal (or orphan <strong>?+</strong>) as that card.</div>
                <div id="blind-steals-list"></div>
              </div>
            </div>
            <div class="condensed-stats" id="condensed-opp-stats-wrap">
              <div class="condensed-row" id="condensed-opp-1v1">
                ${condensedItems("opp")}
              </div>
              <div id="condensed-opp-4p" aria-hidden="true"></div>
            </div>
          </div>
          
          <!-- My Resources Section -->
          <div class="section" data-section-type="myresources">
            <div class="section-header">
              <strong>📊 My Resources</strong>
              <div class="section-header-buttons">
                <button id="myres-minimize">−</button>
                <button id="myres-clear">Clear</button>
              </div>
            </div>
            <div class="section-content" id="myres-content">
              ${resourceRows("me")}
            </div>
            <div class="condensed-stats">
              <div class="condensed-row">
                ${condensedItems("me")}
              </div>
            </div>
          </div>
          
          <!-- Dev Cards Section -->
          <div class="section" data-section-type="devcards">
            <div class="section-header">
              <strong>🃏 Dev Cards</strong>
              <div class="section-header-buttons">
                <button id="dev-minimize">−</button>
                <button id="dev-clear">Clear</button>
              </div>
            </div>
            <div class="section-content" id="dev-content">
              <div style="font-size:12px; margin-top:6px; line-height:1.8;">
                ${devCardRows}
                <div style="margin-top:8px; padding-top:8px; border-top:1px solid rgba(255,255,255,0.2); font-weight:700;">
                  📦 Total Purchased: <span id="dev-purchased">0</span>/${TOTAL_DEV_CARDS}
                </div>
                <div style="margin-top:4px; font-size:11px; opacity:0.8;">
                  ℹ️ Note: 5 Victory Points exist but are only revealed at game end
                </div>
              </div>
            </div>
            <div class="condensed-stats">
              <div class="condensed-row">
                ${devCondensedItems}
                <div class="condensed-item">
                  <span class="condensed-emoji">📦</span>
                  <span class="condensed-value"><span id="dev-purchased-condensed">0</span><span style="opacity:0.6;font-size:10px;">/${TOTAL_DEV_CARDS}</span></span>
                </div>
              </div>
            </div>
          </div>
          
          <!-- Game History Section -->
          <div class="section" data-section-type="history">
            <div class="section-header">
              <strong>📜 History</strong>
              <div class="section-header-buttons">
                <button id="history-minimize">−</button>
                <button id="save-current-game">Save</button>
              </div>
            </div>
            <div class="section-content" id="history-content">
              <div id="history-list"></div>
            </div>
          </div>
          
          <!-- Setup Section -->
          <div class="section" data-section-type="setup">
            <div class="user-setup-section">
              <div id="username-login-section" style="display:none;">
                <input id="myname" type="text" placeholder="Enter your username..." />
                <button id="save-myname" style="width:100%;">Log In</button>
              </div>
              
              <div id="username-display-section" style="display:none;">
                <div style="display:flex;justify-content:space-between;align-items:center;padding:6px 8px;background:rgba(255,255,255,0.1);border-radius:6px;font-size:12px;">
                  <span>User: <strong id="my-display">—</strong></span>
                  <button id="change-myname" style="padding:2px 8px;font-size:10px;">Edit</button>
                </div>
              </div>
              
              <div style="padding:6px 8px;background:rgba(255,255,255,0.08);border-radius:6px;margin:4px 0;">
                <label for="game-mode-select" style="display:block;font-size:11px;font-weight:600;">Mode</label>
                <select id="game-mode-select">
                  <option value="1v1">1 vs 1</option>
                  <option value="4p">4 players</option>
                </select>
                <div style="font-size:10px;opacity:0.75;margin-top:4px;line-height:1.4;">4-player mode reads names from the log. Hidden steals appear in the steals panel.</div>
              </div>
              
              <div class="opponent-display" style="font-size:12px;padding:6px 8px;">
                <span>Opponent <strong id="opp-display">—</strong></span>
                <button id="edit-opp" style="padding:2px 8px;font-size:10px;">Edit</button>
              </div>
              
              <div id="opp-edit-box" style="display:none;">
                <input id="opp-manual" type="text" placeholder="Enter opponent's name..." style="font-size:12px;padding:4px 6px;" />
                <div class="inline-btn-group">
                  <button id="opp-save" style="font-size:11px;padding:3px 8px;">Save</button>
                  <button id="opp-clear" style="font-size:11px;padding:3px 8px;">Clear</button>
                </div>
              </div>
              
              <div style="display:flex;align-items:center;justify-content:space-between;padding:6px 8px;background:rgba(255,255,255,0.1);border-radius:6px;font-size:12px;margin:4px 0;">
                <span>Skip prompts</span>
                <label style="display:flex;align-items:center;cursor:pointer;">
                  <input type="checkbox" id="suppress-confirms" style="width:auto;margin:0;cursor:pointer;" />
                </label>
              </div>
              
              <button id="rescan-log-btn" style="width:100%;font-size:11px;padding:6px 8px;">Rescan</button>
              <button id="copy-stats-btn" style="width:100%;font-size:11px;padding:6px 8px;">Copy Stats</button>
              <button id="full-reset" style="width:100%;font-size:11px;padding:4px 8px;">New Game</button>
            </div>
          </div>
        </div>
        
        <!-- Info Popup -->
        <div id="info-popup-overlay">
          <div id="info-popup">
            <h2>Catan Tracker Guide</h2>
            
            <h3>Quick Start</h3>
            <p>1. Enter your Colonist.io username in the "Setup" section<br>
            2. Choose <strong>1 vs 1</strong> or <strong>4 players</strong>, then start or join a match<br>
            3. The tracker updates from the game log in real time.</p>
            
            <h3>Sections</h3>
            <ul>
              <li><strong>Dice:</strong> Histogram of all rolls, plus recent rolls and 7s.</li>
              <li><strong>Hands:</strong> 1v1 estimates opponent cards; 4-player tracks each opponent.</li>
              <li><strong>My Resources:</strong> Total resources gained this game by type.</li>
              <li><strong>Dev Cards:</strong> Cards played and deck progress.</li>
              <li><strong>History:</strong> Saved games from this browser (manual saves + end/new game saves).</li>
            </ul>

            <h3>Collapsed View</h3>
            <p>When collapsed, hover <strong>🎲</strong> to see the dice graph and hover <strong>🃏</strong> to see dev card progress. This works in both 1v1 and 4-player mode.</p>
            
            <h3>Hover Details</h3>
            <p>Hover over any resource count to see a popup breakdown showing:<br>
            • <strong>Starting:</strong> Resources from initial settlement placement<br>
            • <strong>Rolled:</strong> Resources gained from dice rolls<br>
            • <strong>Stolen:</strong> Resources taken via robber or monopoly card<br>
            • <strong>Bank Trade:</strong> Net resources from trading with bank/ports<br>
            • <strong>Discarded:</strong> Resources lost when a 7 was rolled<br>
            • <strong>Total Gained:</strong> Sum of all resources acquired</p>
            
            <h3>Rescan</h3>
            <p>If the tracker missed something or you started it mid-game:<br>
            1. Click "Rescan"<br>
            2. Scroll to the top of the game log<br>
            3. Slowly scroll down through the full log<br>
            4. Click "Done Scrolling" to process all messages</p>
            
            <h3>Tips</h3>
            <ul>
              <li><strong>Copy Stats:</strong> Share your current game quickly.</li>
              <li><strong>+ / - buttons:</strong> Fine-tune counts when needed.</li>
              <li><strong>Lock Games:</strong> Keep saved games from auto-delete.</li>
              <li><strong>Drag Headers:</strong> Reorder sections.</li>
              <li><strong>Minimize:</strong> Collapse any section to save space.</li>
              <li><strong>Panel position:</strong> Drag position and collapsed/open state are saved automatically.</li>
              <li><strong>Skip prompts:</strong> Toggle confirmations on or off.</li>
            </ul>
            
            <h3>Notes</h3>
            <p>• Opponent's hand is an <strong>estimate</strong> - hidden robber steals can't be tracked perfectly<br>
            • The tracker reads the game log, so it only sees what's visible there<br>
            • Use Rescan if you open the tracker after a game has started</p>
            
            <button id="info-popup-close">Got it!</button>
          </div>
        </div>
      </div>
      
      <div class="tracker-footer">
        Created by <a href="https://www.twitch.tv/Smiller925" target="_blank" rel="noopener noreferrer">Smiller925</a>
      </div>
    `;
  }

  // ─────────────────────────────────────────────────────────────────────────────
  // SECTION 5: LOG PARSER HELPERS
  // ─────────────────────────────────────────────────────────────────────────────

  function imgsToResources(node) {
    const list = [];
    
    // Log all images found in the node for debugging
    const allImgs = node.querySelectorAll("img");
    if (allImgs.length > 0) {
      console.log("[Tracker] imgsToResources - Found", allImgs.length, "images in node");
      allImgs.forEach((img, i) => {
        console.log(`[Tracker]   img[${i}]: alt="${img.getAttribute("alt")}" src="${(img.getAttribute("src") || "").substring(0, 50)}..."`);
      });
    }
    
    // Method 1: img with alt attribute (most common)
    node.querySelectorAll("img[alt]").forEach(img => {
      const alt = img.getAttribute("alt") || "";
      const altLower = alt.toLowerCase();
      
      // Direct mapping
      let key = RESOURCE_NAME_MAP[alt];
      
      // Fallback: check if alt contains resource name
      if (!key) {
        if (altLower.includes("lumber") || altLower.includes("wood")) key = "lumber";
        else if (altLower.includes("brick")) key = "brick";
        else if (altLower.includes("wool") || altLower.includes("sheep")) key = "wool";
        else if (altLower.includes("grain") || altLower.includes("wheat")) key = "grain";
        else if (altLower.includes("ore") || altLower.includes("rock") || altLower.includes("stone")) key = "ore";
      }
      
      if (key) {
        list.push(key);
      }
    });
    
    // Method 2: Check image src URLs
    if (list.length === 0) {
      node.querySelectorAll("img").forEach(img => {
        const src = img.getAttribute("src") || "";
        const srcLower = src.toLowerCase();
        if (srcLower.includes("lumber") || srcLower.includes("wood")) list.push("lumber");
        else if (srcLower.includes("brick")) list.push("brick");
        else if (srcLower.includes("wool") || srcLower.includes("sheep")) list.push("wool");
        else if (srcLower.includes("grain") || srcLower.includes("wheat")) list.push("grain");
        else if (srcLower.includes("ore") || srcLower.includes("rock") || srcLower.includes("stone")) list.push("ore");
      });
    }
    
    // Method 3: Check for card- style classes or data attributes
    if (list.length === 0) {
      node.querySelectorAll("[class*='card'], [class*='resource'], [data-resource]").forEach(el => {
        const className = (el.className || "").toLowerCase();
        const dataRes = (el.getAttribute("data-resource") || "").toLowerCase();
        const combined = className + " " + dataRes;
        
        if (combined.includes("lumber") || combined.includes("wood")) list.push("lumber");
        else if (combined.includes("brick")) list.push("brick");
        else if (combined.includes("wool") || combined.includes("sheep")) list.push("wool");
        else if (combined.includes("grain") || combined.includes("wheat")) list.push("grain");
        else if (combined.includes("ore") || combined.includes("rock")) list.push("ore");
      });
    }
    
    if (list.length > 0) {
      console.log("[Tracker] imgsToResources found:", list);
    } else if (allImgs.length > 0) {
      console.log("[Tracker] ⚠️ imgsToResources found 0 resources despite having", allImgs.length, "images");
    }
    
    return list;
  }

  function imgAltToResourceKey(img) {
    if (!img || img.tagName !== "IMG") return null;
    const alt = img.getAttribute("alt") || "";
    let key = RESOURCE_NAME_MAP[alt];
    if (key) return key;
    const altLower = alt.toLowerCase();
    if (altLower.includes("lumber") || altLower.includes("wood")) return "lumber";
    if (altLower.includes("brick")) return "brick";
    if (altLower.includes("wool") || altLower.includes("sheep")) return "wool";
    if (altLower.includes("grain") || altLower.includes("wheat")) return "grain";
    if (altLower.includes("ore") || altLower.includes("rock") || altLower.includes("stone")) return "ore";
    const src = (img.getAttribute("src") || "").toLowerCase();
    if (src.includes("lumber") || src.includes("wood")) return "lumber";
    if (src.includes("brick")) return "brick";
    if (src.includes("wool") || src.includes("sheep")) return "wool";
    if (src.includes("grain") || src.includes("wheat")) return "grain";
    if (src.includes("ore") || src.includes("rock") || src.includes("stone")) return "ore";
    return null;
  }

  /** Full log row text (Colonist splits content across spans; messagePart-only text misses keywords). */
  function getLogRowText(node, messagePartText) {
    if (node && (node.innerText || node.textContent)) {
      const t = String(node.innerText || node.textContent || "").trim();
      if (t) return t;
    }
    return String(messagePartText || "").trim();
  }

  function linearizeLogNodeForTrade(node) {
    const parts = [];
    function visit(n) {
      if (!n) return;
      if (n.nodeType === 3) {
        const t = n.textContent || "";
        if (t) parts.push({ kind: "text", text: t });
      } else if (n.nodeType === 1) {
        if (n.tagName === "IMG") {
          const key = imgAltToResourceKey(n);
          if (key) parts.push({ kind: "img", key });
        } else if (n.childNodes) {
          for (let i = 0; i < n.childNodes.length; i++) visit(n.childNodes[i]);
        }
      }
    }
    visit(node);
    return parts;
  }

  function parseColonistPlayerTradeGivenTaken(node, rowLower) {
    const parts = linearizeLogNodeForTrade(node);
    const flatKeys = parts.filter(p => p.kind === "img").map(p => p.key);
    let forIdx = -1;
    for (let i = 0; i < parts.length; i++) {
      if (parts[i].kind === "text" && /\sfor\s/i.test(parts[i].text)) {
        forIdx = i;
        break;
      }
    }
    const given = [];
    const taken = [];
    if (forIdx !== -1) {
      for (let i = 0; i < parts.length; i++) {
        if (parts[i].kind !== "img") continue;
        if (i < forIdx) given.push(parts[i].key);
        else taken.push(parts[i].key);
      }
    } else if (
      colonistRowLooksLikePlayerTrade(rowLower) &&
      flatKeys.length >= 2 &&
      flatKeys.length % 2 === 0
    ) {
      const half = flatKeys.length / 2;
      given.push(...flatKeys.slice(0, half));
      taken.push(...flatKeys.slice(half));
    }
    return { given, taken };
  }

  /**
   * Colonist completed trade: "Geiger gave [brick] and got [lumber] from Chu"
   * Actor loses `given`, gains `taken`; partner the opposite.
   */
  function parseColonistGaveAndGotFromPartner(node, rowText) {
    const rl = String(rowText || "").toLowerCase();
    if (!/\bgave\b/.test(rl) || !/\band\s+got\b/.test(rl) || !/\bfrom\b/.test(rl)) return null;
    if (/\bgave\s+bank\b/i.test(rl)) return null;
    const parts = linearizeLogNodeForTrade(node);
    let afterGave = false;
    let afterGotKw = false;
    let afterFromKw = false;
    const given = [];
    const taken = [];
    const namePieces = [];

    for (const p of parts) {
      if (p.kind === "text") {
        const tx = p.text;
        if (!afterGave && /\bgave\b/i.test(tx)) afterGave = true;
        if (afterGave && !afterGotKw && /\band\s+got\b/i.test(tx)) afterGotKw = true;
        if (afterGotKw && /\bfrom\b/i.test(tx)) {
          afterFromKw = true;
          const tail = (tx.split(/\bfrom\b/i).pop() || "").trim();
          if (tail) namePieces.push(tail);
          continue;
        }
        if (afterFromKw && tx.trim()) namePieces.push(tx.trim());
      } else if (p.kind === "img") {
        if (afterGave && !afterGotKw) given.push(p.key);
        else if (afterGotKw && !afterFromKw) taken.push(p.key);
      }
    }

    let partnerRaw = namePieces.join(" ").replace(/\s+/g, " ").trim().replace(/^[,.\s:]+/, "").trim();
    let partnerSan = partnerRaw ? sanitizeTradePartnerCapture(partnerRaw) : null;
    if (!partnerSan) {
      const fm = String(rowText || "").match(/\bgave\b[\s\S]*?\band\s+got\b[\s\S]*?\bfrom\s+([^\n.]+?)(?:\.|$)/i);
      if (fm) partnerSan = sanitizeTradePartnerCapture(fm[1].trim());
    }
    const partnerName =
      partnerSan ||
      (partnerRaw && !isInvalidTradePartnerLabel(partnerRaw) ? partnerRaw : null);
    if (!given.length || !taken.length || !partnerName || isInvalidTradePartnerLabel(partnerName)) return null;
    return { given, taken, partnerName };
  }

  function applyColonistGaveGotFromTrade4p(text, node, rowText, rowLower) {
    const parsed = parseColonistGaveAndGotFromPartner(node, rowText);
    if (!parsed) return false;
    const { given, taken, partnerName } = parsed;
    const actor = getActorFromLogLine(text) || getActorFromLogLine(rowText);
    const partnerKey = resolveNameToKey(partnerName);
    if (!actor || !partnerKey || actor.key === partnerKey) return false;
    given.forEach(r => trackPlayerResource4p(actor.key, r, -1, "bankTrade"));
    taken.forEach(r => trackPlayerResource4p(actor.key, r, 1, "bankTrade"));
    given.forEach(r => trackPlayerResource4p(partnerKey, r, 1, "bankTrade"));
    taken.forEach(r => trackPlayerResource4p(partnerKey, r, -1, "bankTrade"));
    console.log("[Tracker] 4p gave/got/from trade:", actor.displayName, "<->", partnerName, { given, taken });
    return true;
  }

  function applyColonistGaveGotFromTrade1v1(text, node, rowText, rowLower, myLower) {
    const parsed = parseColonistGaveAndGotFromPartner(node, rowText);
    if (!parsed) return false;
    const { given, taken, partnerName } = parsed;
    const actor = getActorFromLogLine(text) || getActorFromLogLine(rowText);
    if (!actor) return false;
    const partnerKey = resolveNameToKey(partnerName);
    if (!partnerKey || actor.key === partnerKey) return false;
    const currentOppLower = (state.opponentName || "").trim().toLowerCase();
    const actorIsMe = !!actor.isMe;
    const partnerIsMe = partnerKey === myLower;
    const actorIsOpp = currentOppLower && actor.key === currentOppLower;
    const partnerIsOpp = currentOppLower && partnerKey === currentOppLower;
    if (actorIsMe && partnerIsOpp) {
      given.forEach(r => trackResource("me", r, -1, "bankTrade"));
      taken.forEach(r => trackResource("me", r, 1, "bankTrade"));
      given.forEach(r => trackResource("opp", r, 1, "bankTrade"));
      taken.forEach(r => trackResource("opp", r, -1, "bankTrade"));
      console.log("[Tracker] 1v1 gave/got/from trade: me <-> opp", { given, taken });
      return true;
    }
    if (actorIsOpp && partnerIsMe) {
      given.forEach(r => trackResource("opp", r, -1, "bankTrade"));
      taken.forEach(r => trackResource("opp", r, 1, "bankTrade"));
      given.forEach(r => trackResource("me", r, 1, "bankTrade"));
      taken.forEach(r => trackResource("me", r, -1, "bankTrade"));
      console.log("[Tracker] 1v1 gave/got/from trade: opp <-> me", { given, taken });
      return true;
    }
    return false;
  }

  /** Cut partner capture at UI/log glue ("… with player game and …"). */
  function clampTradePartnerFragment(raw) {
    if (!raw) return "";
    let s = String(raw).trim().replace(/\.$/, "");
    const stop = /\s+(?:and|or|but|for|from|to|was|were|is|are|has|have|accepted|completed|the\s+trade|trade\s+with|rolling|rolled|turn)\b/i;
    const i = s.search(stop);
    if (i > 0) s = s.slice(0, i).trim();
    s = s.replace(/^(the|a|an)\s+/i, "").trim();
    return s;
  }

  /** Reject Colonist DOM noise mistaken for a display name. */
  function isInvalidTradePartnerLabel(s) {
    const t = String(s || "").trim();
    const lower = t.toLowerCase();
    if (!t || t.length > 36) return true;
    if (/^player(\s+game)?(\s+and)?$/i.test(lower)) return true;
    if (/^the\s+player$/i.test(lower)) return true;
    if (/\bplayer\s+game\b/i.test(lower)) return true;
    if (/\bgame\s+and\b/i.test(lower)) return true;
    if (/\b(colonist|trade\s+offer)\b/i.test(lower)) return true;
    const tokens = lower.split(/\s+/).filter(Boolean);
    const onlyGeneric = new Set(["player", "a", "the", "an", "game", "and", "or", "for", "to", "from", "trade"]);
    if (tokens.length >= 2 && tokens.every(w => onlyGeneric.has(w))) return true;
    return false;
  }

  function sanitizeTradePartnerCapture(capture) {
    const clamped = clampTradePartnerFragment(capture);
    if (!clamped || isInvalidTradePartnerLabel(clamped)) return null;
    return clamped;
  }

  function extractTradePartnerNameRaw(rowText) {
    if (!rowText) return null;
    const patterns = [
      /\bcompleted\s+(?:a\s+)?trade\s+with\s+([^\n]+?)(?=\s*[.,]|\s+for\s|\s+and\s+|$)/i,
      /\btrade\s+with\s+([^\n]+?)(?=\s*[.,]|\s+for\s|\s+and\s+|$)/i,
      /\btraded\s+[\s\S]{0,200}?\bwith\s+([^\n]+?)(?=\s*[.,]|\s+for\s|\s+and\s+|$)/i,
      /\bwith\s+([^\n.,]+?)(?=\s*$|[.,]|\s+for\s|\s+and\s+)/i
    ];
    for (const re of patterns) {
      const m = rowText.match(re);
      if (!m) continue;
      const s = sanitizeTradePartnerCapture(m[1]);
      if (s) return s;
    }
    return null;
  }

  function imgsToDice(node) {
    const vals = [];
    node.querySelectorAll("img[alt]").forEach(img => {
      const m = (img.getAttribute("alt") || "").match(/dice_(\d+)/);
      if (m) {
        const v = parseInt(m[1], 10);
        if (v >= 1 && v <= 6) vals.push(v);
      }
    });
    return vals;
  }

  function imgsToDevTypes(node) {
    const found = [];
    node.querySelectorAll("img[alt]").forEach(img => {
      const alt = (img.getAttribute("alt") || "").toLowerCase();
      DEV_CARD_TYPES.forEach(t => {
        if (alt.includes(t.toLowerCase())) found.push(t);
      });
    });
    return found;
  }

  function detectPlayedDevCard(lowerText, node) {
    const didUseDevAction = /\b(used|played|activated)\b/.test(lowerText);
    if (!didUseDevAction) return null;

    const devTypesFromImages = imgsToDevTypes(node);
    if (devTypesFromImages.length > 0) {
      const firstType = devTypesFromImages.find(t => t !== "Victory Point");
      if (firstType) return firstType;
    }

    if (/\bmonopoly\b/.test(lowerText)) return "Monopoly";
    if (/\b(year of plenty|plenty)\b/.test(lowerText)) return "Year of Plenty";
    if (/\broad building\b/.test(lowerText)) return "Road Building";
    if (/\b(knight|soldier)\b/.test(lowerText)) return "Knight";
    return null;
  }

  function escapeRegex(str) {
    return str.replace(/[.*+?^${}()|[\]\\]/g, '\\$&');
  }

  /**
   * Try to detect opponent name from any message that starts with a player name
   * This is a fallback when we miss the "starting resources" message
   */
  function tryDetectOpponentFromMessage(text) {
    if (!state.myName || state.opponentName || state.opponentManual) return null;
    
    const myLower = state.myName.trim().toLowerCase();
    const lower = text.toLowerCase();
    
    // Skip if it's about me
    if (lower.startsWith("you ") || lower.startsWith(myLower + " ")) return null;
    
    // Patterns that start with a player name
    const patterns = [
      /^(.+?)\s+rolled/i,
      /^(.+?)\s+got\s/i,
      /^(.+?)\s+built/i,
      /^(.+?)\s+bought/i,
      /^(.+?)\s+played/i,
      /^(.+?)\s+used/i,
      /^(.+?)\s+placed/i,
      /^(.+?)\s+received starting resources/i
    ];
    
    for (const pattern of patterns) {
      const match = text.match(pattern);
      if (match) {
        const playerName = match[1].trim();
        const playerLower = playerName.toLowerCase();
        
        // Make sure it's not me and not a system message
        if (playerLower !== "you" && 
            playerLower !== myLower && 
            playerName.length > 1 &&
            playerName.length < 30 &&
            !playerName.includes(":")) {
          console.log("[Tracker] 🎯 Auto-detected opponent from message:", playerName, "| Pattern:", pattern);
          return playerName;
        }
      }
    }
    
    return null;
  }

  // ─────────────────────────────────────────────────────────────────────────────
  // MULTIPLAYER (4p) HELPERS
  // ─────────────────────────────────────────────────────────────────────────────

  function escapeHtml(s) {
    return String(s || "")
      .replace(/&/g, "&amp;")
      .replace(/</g, "&lt;")
      .replace(/>/g, "&gt;")
      .replace(/"/g, "&quot;");
  }

  /** Safe fragment for HTML ids (player keys may include spaces). */
  function playerDomId(key) {
    return String(key || "p").replace(/[^a-zA-Z0-9_-]/g, "_");
  }

  function playerKeyFromName(displayName, isMe) {
    const myLower = (state.myName || "").trim().toLowerCase();
    if (isMe) return myLower || null;
    const t = (displayName || "").trim();
    if (!t) return null;
    const l = t.toLowerCase();
    if (l === "you") return myLower || null;
    return l;
  }

  function ensurePlayerRecord(displayName, isMe) {
    const key = playerKeyFromName(isMe ? state.myName : displayName, isMe);
    if (!key) return null;
    const disp = isMe ? (state.myName || "You") : String(displayName || "").trim();
    if (!state.players[key]) {
      state.players[key] = {
        key,
        displayName: disp,
        isMe: !!isMe,
        resources: createEmptyResources(),
        tracking: createResourceTracking(),
        unknownGained: 0,
        unknownLost: 0,
        sevens: 0,
        devBuys: 0,
        devCardsHeld: 0,
        colonistColor: null
      };
    } else if (disp && !isMe) {
      state.players[key].displayName = disp;
    }
    if (typeof state.players[key].devCardsHeld !== "number") state.players[key].devCardsHeld = 0;
    if (typeof state.players[key].colonistColor !== "string") state.players[key].colonistColor = null;
    return state.players[key];
  }

  /** Safe CSS color for inline style (hex or rgb only). */
  function sanitizeColonistColorForCss(raw) {
    if (!raw || typeof raw !== "string") return null;
    const s = raw.trim().replace(/^["']|["']$/g, "");
    if (/^#[0-9a-f]{6}$/i.test(s) || /^#[0-9a-f]{3}$/i.test(s)) return s;
    if (/^#[0-9a-f]{8}$/i.test(s)) return s.slice(0, 7);
    const rgb = s.match(/^rgba?\(\s*(\d{1,3})\s*,\s*(\d{1,3})\s*,\s*(\d{1,3})/i);
    if (rgb) {
      const clamp = n => Math.max(0, Math.min(255, parseInt(n, 10)));
      const h = n => clamp(n).toString(16).padStart(2, "0");
      return "#" + h(rgb[1]) + h(rgb[2]) + h(rgb[3]);
    }
    return null;
  }

  function styleLooksLikeColonistPlayerName(styleAttr) {
    const st = String(styleAttr || "");
    if (!/color\s*:/i.test(st)) return false;
    return (
      /font-weight\s*:\s*600\b/i.test(st) ||
      /font-weight\s*:\s*700\b/i.test(st) ||
      /word-break\s*:\s*break-all/i.test(st)
    );
  }

  /** Read Colonist player colors from log row DOM (bold colored name spans). */
  function syncPlayerColorsFromLogNode(node) {
    if (!node || state.gameMode !== "4p") return;
    const myLower = (state.myName || "").trim().toLowerCase();
    const spans = node.querySelectorAll("span[style]");
    spans.forEach(span => {
      const st = span.getAttribute("style") || "";
      if (!styleLooksLikeColonistPlayerName(st)) return;
      const cm = st.match(/color\s*:\s*([^;]+)/i);
      if (!cm) return;
      const hex = sanitizeColonistColorForCss(cm[1]);
      if (!hex) return;
      const nameText = (span.textContent || "").trim();
      if (!nameText || nameText.length > 36) return;
      const nl = nameText.toLowerCase();
      const isMe = nl === "you" || (myLower && nl === myLower);
      if (isMe && !state.myName) return;
      const disp = isMe ? state.myName : nameText;
      const p = ensurePlayerRecord(disp, isMe);
      if (p) p.colonistColor = hex;
    });
  }

  function playerColonistColorInlineStyle(p) {
    const c = p && sanitizeColonistColorForCss(p.colonistColor);
    return c ? ` style="color:${c}"` : "";
  }

  function coloredPlayerNameHtml(p, fallbackRaw) {
    const label = escapeHtml((p && p.displayName) || String(fallbackRaw || "").trim() || "?");
    const c = p && sanitizeColonistColorForCss(p.colonistColor);
    if (!c) return label;
    return `<span style="color:${c};font-weight:700;">${label}</span>`;
  }

  function syncPlayerOrder4pWithPlayers() {
    if (!Array.isArray(state.playerOrder4p)) state.playerOrder4p = [];
    const otherKeys = Object.values(state.players)
      .filter(p => p && !p.isMe)
      .map(p => p.key);
    const set = new Set(otherKeys);
    state.playerOrder4p = state.playerOrder4p.filter(k => set.has(k));
    otherKeys.forEach(k => {
      if (!state.playerOrder4p.includes(k)) state.playerOrder4p.push(k);
    });
  }

  function orderedOtherPlayers4p() {
    syncPlayerOrder4pWithPlayers();
    const byKey = {};
    Object.values(state.players).forEach(p => {
      if (p && !p.isMe) byKey[p.key] = p;
    });
    const out = [];
    (state.playerOrder4p || []).forEach(k => {
      if (byKey[k]) out.push(byKey[k]);
    });
    return out;
  }

  function movePlayerOrder4p(playerKey, dir) {
    if (state.gameMode !== "4p" || !playerKey) return;
    syncPlayerOrder4pWithPlayers();
    const arr = state.playerOrder4p;
    const i = arr.indexOf(playerKey);
    if (i < 0) return;
    const j = i + (dir < 0 ? -1 : 1);
    if (j < 0 || j >= arr.length) return;
    const tmp = arr[i];
    arr[i] = arr[j];
    arr[j] = tmp;
  }

  function playerOrderControlButtonsHtml(p, compact) {
    const k = escapeHtml(p.key);
    if (compact) {
      return `<span class="order-ctrl order-ctrl-compact">
        <button type="button" class="order-btn-compact" data-player-order="${k}" data-dir="-1" title="Move up">▲</button>
        <button type="button" class="order-btn-compact" data-player-order="${k}" data-dir="1" title="Move down">▼</button>
      </span>`;
    }
    return `<span class="order-ctrl order-ctrl-full">
      <button type="button" class="order-btn-full" data-player-order="${k}" data-dir="-1" title="Move up in list">↑</button>
      <button type="button" class="order-btn-full" data-player-order="${k}" data-dir="1" title="Move down in list">↓</button>
    </span>`;
  }

  function getActorFromLogLine(text) {
    const myLower = (state.myName || "").trim().toLowerCase();
    if (!myLower) return null;
    const lower = text.toLowerCase();
    if (text.startsWith("You ") || text.startsWith("You,")) return ensurePlayerRecord(state.myName, true);
    if (lower.startsWith(myLower + " ")) return ensurePlayerRecord(state.myName, true);
    const m = text.match(
      /^(.+?)\s+(rolled|got|built|bought|placed|received|discarded|traded|stole|took|completed|accepted|gave)/i
    );
    if (!m) return null;
    const name = m[1].trim();
    const nl = name.toLowerCase();
    if (nl === "you") return ensurePlayerRecord(state.myName, true);
    if (nl === myLower) return ensurePlayerRecord(state.myName, true);
    return ensurePlayerRecord(name, false);
  }

  function resolveNameToKey(nameRaw) {
    const n = String(nameRaw || "").trim().replace(/\.$/, "");
    if (!n) return null;
    const nl = n.toLowerCase();
    const myLower = (state.myName || "").trim().toLowerCase();
    if (nl === "you" || (myLower && nl === myLower)) {
      const me = ensurePlayerRecord(state.myName, true);
      return me ? me.key : null;
    }
    const p = ensurePlayerRecord(n, false);
    return p ? p.key : null;
  }

  function parseRobberThiefVictim(text, lower) {
    let m = text.match(/^(.+?)\s+stole\s+(?:a\s+)?resource\s+from\s+(.+?)(?:\.|$)/i);
    if (m) return { thief: m[1].trim(), victim: m[2].trim().replace(/\.$/, "") };
    m = text.match(/^(.+?)\s+stole\s+from\s+(.+?)(?:\.|$)/i);
    if (m) return { thief: m[1].trim(), victim: m[2].trim().replace(/\.$/, "") };
    return null;
  }

  /** Resources the victim could have lost (only types they show with count &gt; 0); else all five. */
  function narrowVictimStealPossibilities(victim) {
    if (!victim) return RESOURCES.slice();
    const pos = RESOURCES.filter(r => (victim.resources[r] || 0) > 0);
    return pos.length ? pos : RESOURCES.slice();
  }

  function registerBlindSteal(thiefKey, victimKey) {
    if (!thiefKey || !victimKey || thiefKey === victimKey) return;
    const thief = state.players[thiefKey];
    const victim = state.players[victimKey];
    if (!thief || !victim) return;
    thief.unknownGained = (thief.unknownGained || 0) + 1;
    victim.unknownLost = (victim.unknownLost || 0) + 1;
    const id = state.nextBlindStealId++;
    const possibilities = narrowVictimStealPossibilities(victim);
    state.blindSteals.push({
      id,
      thiefKey,
      victimKey,
      possibilities
    });
    console.log("[Tracker] Blind robber steal registered:", { id, thiefKey, victimKey, possibilities });
    if (!isRescanning) {
      renderHand();
      saveState();
    }
  }

  function findTradePartnerKey(lower, text) {
    const rowText = text || "";
    const myLower = (state.myName || "").trim().toLowerCase();
    const name = extractTradePartnerNameRaw(rowText);
    if (!name) return null;
    if (/^you$/i.test(name)) return myLower || null;
    return resolveNameToKey(name);
  }

  function isColonistBankPortTradePartnerName(nameRaw) {
    const n = String(nameRaw || "").trim().toLowerCase();
    if (!n) return false;
    return (
      /^(the\s+)?bank$/i.test(n) ||
      /^a\s+(\d+:\d+\s+)?port$/i.test(n) ||
      /^(\d+:\d+)\s+port$/i.test(n)
    );
  }

  /** Player–player trade wording in log; excludes trades with the bank. */
  function colonistRowLooksLikePlayerTrade(rowLower) {
    if (!rowLower || /\bwith\s+(the\s+)?bank\b/i.test(rowLower)) return false;
    if (!/\bwith\b/i.test(rowLower)) return false;
    if (/\btraded\b/i.test(rowLower)) return true;
    if (/\btrade\s+with\b/i.test(rowLower)) return true;
    if (/\bcompleted\s+(a\s+)?trade\b/i.test(rowLower)) return true;
    if (/\baccepted\b/i.test(rowLower) && /\btrade\b/i.test(rowLower)) {
      const ai = rowLower.search(/\baccepted\b/i);
      const ti = rowLower.search(/\btrade\b/i);
      const wi = rowLower.search(/\bwith\b/i);
      if (ai !== -1 && ti !== -1 && wi !== -1 && ai < ti && ti < wi) return true;
    }
    return false;
  }

  function applyColonistPlayerTrade4p(text, node, rowText, rowLower) {
    if (!colonistRowLooksLikePlayerTrade(rowLower)) return false;
    const { given, taken } = parseColonistPlayerTradeGivenTaken(node, rowLower);
    if (!given.length || !taken.length) return false;
    const actor = getActorFromLogLine(text) || getActorFromLogLine(rowText);
    const partnerRaw = extractTradePartnerNameRaw(rowText);
    if (partnerRaw && isColonistBankPortTradePartnerName(partnerRaw)) return false;
    const partnerKey = findTradePartnerKey(rowLower, rowText);
    if (!actor || !partnerKey || actor.key === partnerKey) return false;
    given.forEach(r => trackPlayerResource4p(actor.key, r, -1, "bankTrade"));
    taken.forEach(r => trackPlayerResource4p(actor.key, r, 1, "bankTrade"));
    given.forEach(r => trackPlayerResource4p(partnerKey, r, 1, "bankTrade"));
    taken.forEach(r => trackPlayerResource4p(partnerKey, r, -1, "bankTrade"));
    console.log("[Tracker] 4p player trade:", actor.displayName, "<->", partnerKey, { given, taken });
    return true;
  }

  function tryApplyGotLineAsPlayerTrade4p(text, node, rowText, rowLower) {
    if (!/\sgot\b/i.test(rowLower)) return false;
    if (
      !/\b(from\s+(a\s+)?trade|from\s+trading|trade\s+with|completed\s+(a\s+)?trade|accepted\s+(a\s+)?trade|via\s+(a\s+)?trade)\b/i.test(
        rowLower
      )
    ) {
      return false;
    }
    if (/\bwith\s+(the\s+)?bank\b/i.test(rowLower)) return false;
    const actor = getActorFromLogLine(text) || getActorFromLogLine(rowText);
    const resources = imgsToResources(node);
    if (!actor || !resources.length) return false;
    const partnerRaw = extractTradePartnerNameRaw(rowText);
    if (partnerRaw && isColonistBankPortTradePartnerName(partnerRaw)) return false;
    const partnerKey = findTradePartnerKey(rowLower, rowText);
    if (!partnerKey || partnerKey === actor.key) return false;
    resources.forEach(r => trackPlayerResource4p(actor.key, r, 1, "bankTrade"));
    resources.forEach(r => trackPlayerResource4p(partnerKey, r, -1, "bankTrade"));
    console.log("[Tracker] 4p got-from-trade:", actor.displayName, resources, "from", partnerKey);
    return true;
  }

  function applyColonistPlayerTrade1v1(text, node, rowText, rowLower, myLower) {
    if (!colonistRowLooksLikePlayerTrade(rowLower)) return false;
    const partnerNameCheck = extractTradePartnerNameRaw(rowText);
    if (partnerNameCheck && isColonistBankPortTradePartnerName(partnerNameCheck)) return false;
    const { given, taken } = parseColonistPlayerTradeGivenTaken(node, rowLower);
    if (!given.length || !taken.length) return false;
    const currentOppLower = (state.opponentName || "").trim().toLowerCase();
    const isMe = rowText.startsWith("You ") || (myLower && rowLower.startsWith(myLower + " "));
    const isOpp = currentOppLower && rowLower.startsWith(currentOppLower + " ");
    const withMePattern = new RegExp(`with\\s+(you|${myLower ? escapeRegex(myLower) : "NOMATCH"})\\b`, "i");
    const withOppPattern = currentOppLower ? new RegExp(`with\\s+${escapeRegex(currentOppLower)}\\b`, "i") : null;
    const tradingWithMe = withMePattern.test(rowLower);
    const tradingWithOpp = withOppPattern && withOppPattern.test(rowLower);
    if (isMe) {
      given.forEach(r => trackResource("me", r, -1, "bankTrade"));
      taken.forEach(r => trackResource("me", r, 1, "bankTrade"));
      if (tradingWithOpp) {
        given.forEach(r => trackResource("opp", r, 1, "bankTrade"));
        taken.forEach(r => trackResource("opp", r, -1, "bankTrade"));
      }
      return true;
    }
    if (isOpp) {
      given.forEach(r => trackResource("opp", r, -1, "bankTrade"));
      taken.forEach(r => trackResource("opp", r, 1, "bankTrade"));
      if (tradingWithMe) {
        given.forEach(r => trackResource("me", r, 1, "bankTrade"));
        taken.forEach(r => trackResource("me", r, -1, "bankTrade"));
      }
      return true;
    }
    return false;
  }

  const SPEND_SOURCES_IMPUTE_4P = new Set(["rolled", "bankTrade", "discarded"]);

  /** Apply resource delta without spend-imputation (blind-steal resolve + orphan ?+ only). */
  function applyRawPlayerResourceDelta4p(playerKey, res, delta, source) {
    const p = state.players[playerKey];
    if (!p || !res) return;
    const tracking = p.tracking;
    if (!tracking[res]) {
      tracking[res] = { starting: 0, rolled: 0, stolen: 0, bankTrade: 0, discarded: 0, total: 0 };
    }
    if (typeof p.resources[res] !== "number") p.resources[res] = 0;
    p.resources[res] = Math.max(0, (p.resources[res] || 0) + delta);
    if (delta > 0 && source === "stolen") {
      tracking[res].stolen = (tracking[res].stolen || 0) + delta;
      tracking[res].total = (tracking[res].total || 0) + delta;
    }
    if (p.isMe) {
      state.myResources[res] = p.resources[res];
      state.myTracking[res] = { ...tracking[res] };
    }
  }

  function resolveBlindStealWithResource(bsId, res) {
    const idx = state.blindSteals.findIndex(b => b.id === bsId);
    if (idx === -1) return false;
    const bs = state.blindSteals[idx];
    const poss = bs.possibilities && bs.possibilities.length ? bs.possibilities : RESOURCES.slice();
    if (!poss.includes(res)) return false;
    const thief = state.players[bs.thiefKey];
    const victim = state.players[bs.victimKey];
    if (!thief || !victim) return false;
    state.blindSteals.splice(idx, 1);
    thief.unknownGained = Math.max(0, (thief.unknownGained || 0) - 1);
    victim.unknownLost = Math.max(0, (victim.unknownLost || 0) - 1);
    applyRawPlayerResourceDelta4p(bs.thiefKey, res, 1, "stolen");
    applyRawPlayerResourceDelta4p(bs.victimKey, res, -1, "stolen");
    console.log("[Tracker] Auto-resolved blind steal #" + bsId, "as", res, thief.displayName, "←", victim.displayName);
    return true;
  }

  function pickBlindStealForThiefResource(thiefKey, res) {
    const candidates = state.blindSteals.filter(bs => {
      if (bs.thiefKey !== thiefKey) return false;
      const poss = bs.possibilities && bs.possibilities.length ? bs.possibilities : RESOURCES.slice();
      return poss.includes(res);
    });
    if (!candidates.length) return null;
    candidates.sort((a, b) => {
      const va = state.players[a.victimKey];
      const vb = state.players[b.victimKey];
      const ha = va && (va.resources[res] || 0) > 0 ? 1 : 0;
      const hb = vb && (vb.resources[res] || 0) > 0 ? 1 : 0;
      if (ha !== hb) return hb - ha;
      const la = (a.possibilities || RESOURCES).length;
      const lb = (b.possibilities || RESOURCES).length;
      if (la !== lb) return la - lb;
      return a.id - b.id;
    });
    return candidates[0];
  }

  /**
   * If a spend would use cards the tracker doesn't show, impute hidden gains:
   * prefer resolving a blind robber steal (thief + victim + remove record), else orphan ?+ only when no pending steals for this thief.
   */
  function imputeOneHiddenCardForSpend4p(playerKey, res) {
    const bs = pickBlindStealForThiefResource(playerKey, res);
    if (bs) return resolveBlindStealWithResource(bs.id, res);
    const pendingForThief = state.blindSteals.filter(b => b.thiefKey === playerKey);
    if (pendingForThief.length > 0) return false;
    const p = state.players[playerKey];
    if (!p || (p.unknownGained || 0) <= 0) return false;
    p.unknownGained--;
    applyRawPlayerResourceDelta4p(playerKey, res, 1, "stolen");
    console.log("[Tracker] Imputed hidden +1", res, "for", p.displayName || playerKey, "(orphan ?+)");
    return true;
  }

  function tryApplyGotLineAsPlayerTrade1v1(text, node, rowText, rowLower, myLower) {
    if (!/\sgot\b/i.test(rowLower)) return false;
    if (
      !/\b(from\s+(a\s+)?trade|from\s+trading|trade\s+with|completed\s+(a\s+)?trade|accepted\s+(a\s+)?trade|via\s+(a\s+)?trade)\b/i.test(
        rowLower
      )
    ) {
      return false;
    }
    if (/\bwith\s+(the\s+)?bank\b/i.test(rowLower)) return false;
    const currentOppLower = (state.opponentName || "").trim().toLowerCase();
    const isMe = text.startsWith("You ") || (myLower && rowLower.startsWith(myLower + " "));
    const isOpp = currentOppLower && rowLower.startsWith(currentOppLower + " ");
    const resources = imgsToResources(node);
    if (!resources.length) return false;
    const partnerRaw = extractTradePartnerNameRaw(rowText);
    if (partnerRaw && isColonistBankPortTradePartnerName(partnerRaw)) return false;
    const partnerLower = (partnerRaw || "").trim().toLowerCase();
    if (isMe && currentOppLower && partnerLower === currentOppLower) {
      resources.forEach(r => trackResource("me", r, 1, "bankTrade"));
      resources.forEach(r => trackResource("opp", r, -1, "bankTrade"));
      return true;
    }
    if (isOpp && myLower && (partnerLower === "you" || partnerLower === myLower)) {
      resources.forEach(r => trackResource("opp", r, 1, "bankTrade"));
      resources.forEach(r => trackResource("me", r, -1, "bankTrade"));
      return true;
    }
    return false;
  }

  function trackPlayerResource4p(playerKey, res, delta, source) {
    if (!playerKey || !res) return;
    const p = state.players[playerKey];
    if (!p) return;

    const tracking = p.tracking;
    if (!tracking[res]) {
      tracking[res] = { starting: 0, rolled: 0, stolen: 0, bankTrade: 0, discarded: 0, total: 0 };
    }
    if (typeof p.resources[res] !== "number") p.resources[res] = 0;

    if (
      !isRescanning &&
      state.gameMode === "4p" &&
      delta < 0 &&
      SPEND_SOURCES_IMPUTE_4P.has(source)
    ) {
      let avail = p.resources[res] || 0;
      let projected = avail + delta;
      while (projected < 0) {
        if (!imputeOneHiddenCardForSpend4p(playerKey, res)) break;
        avail = p.resources[res] || 0;
        projected = avail + delta;
      }
    }

    p.resources[res] = Math.max(0, (p.resources[res] || 0) + delta);

    if (delta > 0) {
      if (source === "starting") tracking[res].starting = (tracking[res].starting || 0) + delta;
      else if (source === "rolled") tracking[res].rolled = (tracking[res].rolled || 0) + delta;
      else if (source === "stolen") tracking[res].stolen = (tracking[res].stolen || 0) + delta;
      else if (source === "bankTrade") tracking[res].bankTrade = (tracking[res].bankTrade || 0) + delta;
      tracking[res].total = (tracking[res].total || 0) + delta;
    } else if (delta < 0 && source === "discarded") {
      tracking[res].discarded = (tracking[res].discarded || 0) + Math.abs(delta);
    }

    if (p.isMe) {
      state.myResources[res] = p.resources[res];
      state.myTracking[res] = { ...tracking[res] };
    }

    if (!isRescanning) {
      renderHand();
      renderMyResources();
      saveState();
    }
  }

  function sumPlayerHand(p) {
    if (!p) return 0;
    return RESOURCES.reduce((s, r) => s + (p.resources[r] || 0), 0);
  }

  function effectiveHandTotal(p) {
    if (!p) return 0;
    return sumPlayerHand(p) - (p.unknownLost || 0) + (p.unknownGained || 0);
  }

  function totalHandCardsWithDevs(p) {
    if (!p) return 0;
    return effectiveHandTotal(p) + (p.devCardsHeld || 0);
  }

  function resolveUnknownGain4p(playerKey, res) {
    const p = state.players[playerKey];
    if (!p || (p.unknownGained || 0) <= 0) return;
    p.unknownGained--;
    trackPlayerResource4p(playerKey, res, 1, "stolen");
  }

  function resolveUnknownLost4p(playerKey, res) {
    const p = state.players[playerKey];
    if (!p || (p.unknownLost || 0) <= 0) return;
    p.unknownLost--;
    trackPlayerResource4p(playerKey, res, -1, "stolen");
  }

  function buildOnePlayerHandHTML(p) {
    const rows = RESOURCES.map(res => {
      const icon = RESOURCE_ICONS[res];
      const label = res.charAt(0).toUpperCase() + res.slice(1);
      return `
        <div class="res-row">
          <div class="res-name"><span>${icon}</span><span>${label}</span></div>
          <div class="res-count" id="pk-${p.key}-${res}">0</div>
          <div class="res-bar"><div class="bar-inner bar-${res}" id="pk-bar-${p.key}-${res}" style="width:0"></div></div>
          <div class="res-buttons">
            <button type="button" data-player-key="${escapeHtml(p.key)}" data-res="${res}" data-delta="-1">−</button>
            <button type="button" data-player-key="${escapeHtml(p.key)}" data-res="${res}" data-delta="1">+</button>
          </div>
        </div>`;
    }).join("");

    const resBtns = RESOURCES.map(r =>
      `<button type="button" data-resolve-gain="${escapeHtml(p.key)}" data-res="${r}" title="Thief drew ? — count as ${r}">${RESOURCE_ICONS[r]}</button>`
    ).join("");
    const lostBtns = RESOURCES.map(r =>
      `<button type="button" data-resolve-lost="${escapeHtml(p.key)}" data-res="${r}" title="Victim lost ? — was ${r}">${RESOURCE_ICONS[r]}</button>`
    ).join("");

    return `
      <div class="player-hand-block" data-player-key="${escapeHtml(p.key)}">
        <div class="player-hand-title">
          ${playerOrderControlButtonsHtml(p, false)}
          <div class="player-hand-title-center">
            <span class="player-display-name"${playerColonistColorInlineStyle(p)}>${escapeHtml(p.displayName)}</span>${p.isMe ? '<span class="player-you-suffix"> (you)</span>' : ""}
          </div>
          <span class="unknown-tags">?+${p.unknownGained || 0} &nbsp; ?−${p.unknownLost || 0}</span>
        </div>
        <div class="hand-estimate">Res (est.): <strong>${effectiveHandTotal(p)}</strong> · 🃏<strong>${p.devCardsHeld || 0}</strong> · <strong>Σ ${totalHandCardsWithDevs(p)}</strong> total · typed Σ: ${sumPlayerHand(p)}</div>
        ${rows}
        <div class="resolve-unknown-row">
          <span>Resolve ?</span>
          <span style="opacity:0.8;">thief +</span>${resBtns}
          <span style="opacity:0.8;">victim −</span>${lostBtns}
        </div>
      </div>`;
  }

  function updateMultiPlayerRowDisplay(p) {
    if (!root || !p) return;
    RESOURCES.forEach(res => {
      const count = p.resources[res] || 0;
      const countEl = root.querySelector(`#pk-${p.key}-${res}`);
      const barEl = root.querySelector(`#pk-bar-${p.key}-${res}`);
      if (countEl) countEl.textContent = count;
      if (barEl) barEl.style.width = Math.min(count * 10, 130) + "px";
    });
    const multi = $("#opponent-multi-mode");
    if (!multi) return;
    const safeKey = String(p.key).replace(/\\/g, "\\\\").replace(/"/g, '\\"');
    const block = multi.querySelector(`[data-player-key="${safeKey}"]`);
    if (block) {
      const nameEl = block.querySelector(".player-display-name");
      if (nameEl) {
        const c = sanitizeColonistColorForCss(p.colonistColor);
        nameEl.style.color = c || "";
      }
      const tag = block.querySelector(".unknown-tags");
      if (tag) tag.innerHTML = `?+${p.unknownGained || 0} &nbsp; ?−${p.unknownLost || 0}`;
      const est = block.querySelector(".hand-estimate");
      if (est) {
        est.innerHTML = `Res (est.): <strong>${effectiveHandTotal(p)}</strong> · 🃏<strong>${p.devCardsHeld || 0}</strong> · <strong>Σ ${totalHandCardsWithDevs(p)}</strong> total · typed Σ: ${sumPlayerHand(p)}`;
      }
    }
  }

  function renderMultiOpponentHands() {
    const multi = $("#opponent-multi-mode");
    if (!multi) return;
    const list = orderedOtherPlayers4p();
    if (list.length === 0) {
      multi.innerHTML = '<div style="font-size:11px;opacity:0.75;padding:8px;">Play a few turns — player names are taken from the game log.</div>';
      renderBlindStealsList();
      return;
    }
    const keysWant = list.map(p => p.key).join("|");
    const keysHave = [...multi.querySelectorAll(".player-hand-block")]
      .map(el => el.getAttribute("data-player-key"))
      .filter(Boolean)
      .join("|");
    if (keysWant !== keysHave) {
      multi.innerHTML = list.map(p => buildOnePlayerHandHTML(p)).join("");
    }
    list.forEach(p => updateMultiPlayerRowDisplay(p));
    renderBlindStealsList();
  }

  function renderBlindStealsList() {
    const box = $("#blind-steals-list");
    if (!box || state.gameMode !== "4p") return;
    if (!state.blindSteals || !state.blindSteals.length) {
      box.innerHTML = '<div style="opacity:0.65;font-size:10px;">No hidden steals recorded yet.</div>';
      return;
    }
    box.innerHTML = state.blindSteals.map(bs => {
      const thief = state.players[bs.thiefKey];
      const victim = state.players[bs.victimKey];
      const poss = bs.possibilities && bs.possibilities.length ? bs.possibilities : RESOURCES.slice();
      const chips = RESOURCES.map(r => {
        const on = poss.includes(r) ? "checked" : "";
        return `<label><input type="checkbox" data-bs-id="${bs.id}" data-res="${r}" ${on}/> ${RESOURCE_ICONS[r]}</label>`;
      }).join("");
      return `<div class="blind-steal-item" data-bs-id="${bs.id}">
        <div><strong>#${bs.id}</strong> ${coloredPlayerNameHtml(thief, bs.thiefKey)} → ${coloredPlayerNameHtml(victim, bs.victimKey)}</div>
        <div style="font-size:10px;opacity:0.75;">Could be (from victim's hand at steal time):</div>
        <div class="poss-chips">${chips}</div>
        <button type="button" data-bs-remove="${bs.id}" style="margin-top:6px;font-size:10px;padding:2px 8px;">Remove record</button>
      </div>`;
    }).join("");
  }

  function applyGameModeUI() {
    const single = $("#opponent-single-mode");
    const multi = $("#opponent-multi-mode");
    const panel = $("#blind-steals-panel");
    const title = $("#opponent-section-title");
    const line1v1 = $("#sevens-1v1-line");
    const wrap4p = $("#sevens-4p-wrap");
    const sel = $("#game-mode-select");
    if (sel) sel.value = state.gameMode || "1v1";

    const is4 = state.gameMode === "4p";
    const topModeBtn = $("#top-game-mode-toggle");
    if (topModeBtn) {
      topModeBtn.textContent = is4 ? "4p" : "1v1";
      topModeBtn.title = is4 ? "Switch to 1 vs 1" : "Switch to 4 players";
      topModeBtn.setAttribute("aria-label", topModeBtn.title);
    }
    if (single) single.style.display = is4 ? "none" : "block";
    if (multi) multi.style.display = is4 ? "block" : "none";
    if (panel) panel.style.display = is4 ? "block" : "none";
    if (title) title.textContent = is4 ? "👥 Other players (4p) — ↑↓ order" : "👤 Opponent's Hand";
    if (line1v1) line1v1.style.display = is4 ? "none" : "block";
    if (wrap4p) wrap4p.style.display = is4 ? "block" : "none";

    if (is4 && state.myName) ensurePlayerRecord(state.myName, true);
  }

  function commitGameModeChange() {
    if (state.gameMode === "4p" && state.myName) {
      ensurePlayerRecord(state.myName, true);
      if (state.opponentName) ensurePlayerRecord(state.opponentName, false);
    }
    renderAll();
    saveState();
    showNotification(state.gameMode === "4p" ? "👥 4-player mode" : "1 vs 1 mode");
  }

  // ─────────────────────────────────────────────────────────────────────────────
  // SECTION 6: RESOURCE TRACKING
  // ─────────────────────────────────────────────────────────────────────────────

  function trackResource(owner, res, delta, source) {
    console.log("[trackResource]", owner, res, delta, source);
    
    const tracking = owner === "opp" ? state.oppTracking : state.myTracking;
    const resources = owner === "opp" ? state.resources : state.myResources;
    
    if (!tracking[res]) {
      tracking[res] = { starting: 0, rolled: 0, stolen: 0, bankTrade: 0, discarded: 0, total: 0 };
    }
    
    if (typeof resources[res] !== 'number') {
      resources[res] = 0;
    }
    
    const oldValue = resources[res];
    
    // Current hand tracks gains and losses
    resources[res] = Math.max(0, (resources[res] || 0) + delta);
    
    console.log(`[trackResource] ${owner} ${res}: ${oldValue} -> ${resources[res]} (delta: ${delta}, source: ${source})`);
    
    // Track the SOURCE of gains/losses
    // Only positive deltas add to source categories and total
    if (delta > 0) {
      // This is a GAIN - add to the appropriate source category
      if (source === "starting") {
        tracking[res].starting = (tracking[res].starting || 0) + delta;
      } else if (source === "rolled") {
        tracking[res].rolled = (tracking[res].rolled || 0) + delta;
      } else if (source === "stolen") {
        tracking[res].stolen = (tracking[res].stolen || 0) + delta;
      } else if (source === "bankTrade") {
        tracking[res].bankTrade = (tracking[res].bankTrade || 0) + delta;
      }
      // Total gained always increases with positive deltas
      tracking[res].total = (tracking[res].total || 0) + delta;
    } else if (delta < 0) {
      // This is a LOSS - track discards separately
      if (source === "discarded") {
        tracking[res].discarded = (tracking[res].discarded || 0) + Math.abs(delta);
      }
      // Note: Losses from builds/trades don't reduce total - total is "total ever gained"
    }
    
    console.log(`[trackResource] ${owner} ${res} tracking:`, JSON.stringify(tracking[res]));
    
    if (!isRescanning) {
      if (owner === "opp") {
        renderHand();
      } else {
        renderMyResources();
      }
      saveState();
    }
  }

  // ─────────────────────────────────────────────────────────────────────────────
  // SECTION 7: UI RENDERING
  // ─────────────────────────────────────────────────────────────────────────────

  function $(selector) {
    return root ? root.querySelector(selector) : null;
  }

  function renderCollapsedBar4p() {
    const bar = $("#catan-collapsed-bar");
    const one = $("#collapsed-opp-1v1");
    const multi = $("#collapsed-4p-hands");
    if (!bar || !one || !multi) return;

    if (state.gameMode !== "4p") {
      bar.classList.remove("collapsed-4p-mode");
      one.style.display = "flex";
      multi.classList.remove("collapsed-4p-visible");
      multi.innerHTML = "";
      multi.setAttribute("aria-hidden", "true");
      return;
    }

    bar.classList.add("collapsed-4p-mode");
    one.style.display = "none";
    multi.classList.add("collapsed-4p-visible");
    multi.setAttribute("aria-hidden", "false");

    const list = orderedOtherPlayers4p();

    if (!list.length) {
      multi.innerHTML = '<span style="font-size:10px;opacity:0.75;font-weight:600;">Waiting for players…</span>';
      return;
    }

    multi.innerHTML = list.map(p => {
      const sid = playerDomId(p.key);
      const cells = RESOURCES.map(res => `
        <div class="collapsed-res collapsed-res-tiny">
          <span class="res-emoji">${RESOURCE_ICONS[res]}</span>
          <span class="collapsed-count" id="csmall-${sid}-${res}">${p.resources[res] || 0}</span>
        </div>
      `).join("");
      const ug = p.unknownGained || 0;
      const ul = p.unknownLost || 0;
      const q = ug || ul ? `?+${ug}?−${ul}` : "";
      const resTot = effectiveHandTotal(p);
      const devH = p.devCardsHeld || 0;
      const allTot = totalHandCardsWithDevs(p);
      const totTitle = `${resTot} resource cards (est.) + ${devH} dev = ${allTot} total`;
      return `<div class="collapsed-4p-row">
        ${playerOrderControlButtonsHtml(p, true)}
        <span class="collapsed-4p-name" title="${escapeHtml(p.displayName)}"${playerColonistColorInlineStyle(p)}>${escapeHtml(p.displayName)}</span>
        <div class="collapsed-4p-res-strip">${cells}</div>
        <span class="collapsed-4p-totals" title="${totTitle}">${resTot}·🃏${devH}·Σ${allTot}</span>
        ${q ? `<span class="collapsed-4p-q">${q}</span>` : ""}
      </div>`;
    }).join("");
  }

  function renderCondensedOpponents4p() {
    const wrap = $("#condensed-opp-stats-wrap");
    const multi = $("#condensed-opp-4p");
    if (!multi) return;

    if (state.gameMode !== "4p") {
      if (wrap) wrap.classList.remove("condensed-4p-mode");
      multi.classList.remove("condensed-4p-visible");
      multi.innerHTML = "";
      multi.setAttribute("aria-hidden", "true");
      return;
    }

    if (wrap) wrap.classList.add("condensed-4p-mode");
    multi.classList.add("condensed-4p-visible");
    multi.setAttribute("aria-hidden", "false");

    const list = orderedOtherPlayers4p();

    if (!list.length) {
      multi.innerHTML = '<div style="font-size:10px;opacity:0.75;padding:4px 0;">No other players yet.</div>';
      return;
    }

    multi.innerHTML = list.map(p => {
      const sid = playerDomId(p.key);
      const items = RESOURCES.map(res => `
        <div class="condensed-item">
          <span class="condensed-emoji">${RESOURCE_ICONS[res]}</span>
          <span class="condensed-value" id="cond4-${sid}-${res}">${p.resources[res] || 0}</span>
        </div>
      `).join("");
      const ug = p.unknownGained || 0;
      const ul = p.unknownLost || 0;
      const q = ug || ul ? `<span style="font-size:8px;color:#fbbf24;font-weight:700;white-space:nowrap;">?+${ug}?−${ul}</span>` : "";
      const resTot = effectiveHandTotal(p);
      const devH = p.devCardsHeld || 0;
      const allTot = totalHandCardsWithDevs(p);
      return `<div class="condensed-4p-block">
        ${playerOrderControlButtonsHtml(p, true)}
        <span class="condensed-4p-name" title="${escapeHtml(p.displayName)}"${playerColonistColorInlineStyle(p)}>${escapeHtml(p.displayName)}</span>
        <span class="condensed-4p-handtot" title="${resTot} res (est.) + ${devH} dev = ${allTot} total">${resTot}·🃏${devH}·Σ${allTot}</span>
        <div class="condensed-row-inner">${items}</div>
        ${q}
      </div>`;
    }).join("");
  }

  function updateResourceDisplay(owner, res, count, tracking) {
    if (!tracking) {
      tracking = { starting: 0, rolled: 0, stolen: 0, bankTrade: 0, discarded: 0, total: 0 };
    }
    
    const countEl = $(`#${owner}-${res}`);
    const barEl = $(`#${owner}-bar-${res}`);
    const smallEl = $(`#small-${res}`);
    const condensedEl = $(`#${owner}-${res}-condensed`);
    
    if (countEl) countEl.textContent = count;
    if (barEl) barEl.style.width = Math.min(count * 10, 130) + "px";
    if (smallEl && owner === "opp") smallEl.textContent = count;
    if (condensedEl) condensedEl.textContent = count;
    
    ['starting', 'rolled', 'stolen', 'trade', 'discarded', 'total'].forEach(field => {
      const actualField = field === 'trade' ? 'bankTrade' : field;
      const el = $(`#${owner}-${res}-${field}`);
      if (el) el.textContent = tracking[actualField] || 0;
    });
  }

  function renderHand() {
    if (state.gameMode === "4p") {
      renderMultiOpponentHands();
      renderCollapsedBar4p();
      renderCondensedOpponents4p();
      return;
    }
    renderCollapsedBar4p();
    renderCondensedOpponents4p();
    RESOURCES.forEach(k => {
      const tracking = state.oppTracking[k] || { starting: 0, rolled: 0, stolen: 0, bankTrade: 0, discarded: 0, total: 0 };
      updateResourceDisplay("opp", k, state.resources[k] || 0, tracking);
    });
  }

  function renderMyResources() {
    RESOURCES.forEach(k => {
      const tracking = state.myTracking[k] || { starting: 0, rolled: 0, stolen: 0, bankTrade: 0, discarded: 0, total: 0 };
      // "My Resources" shows TOTAL gained (not current hand)
      const totalGained = tracking.total || 0;
      updateResourceDisplay("me", k, totalGained, tracking);
    });
  }

  function renderDevs() {
    DEV_CARD_TYPES.forEach(type => {
      const key = DEV_CARD_KEYS[type];
      const used = state.devUsed[type] || 0;
      const total = DEV_CARD_TOTALS[type];
      
      // Update "used" count (the x in x/y)
      [$(`#dev-${key}`), $(`#dev-${key}-condensed`), $(`#tooltip-dev-${key}`)].forEach(el => {
        if (el) el.textContent = used;
      });
      
      // The "total" (y in x/y) is fixed and set in HTML, no need to update
      // But we'll set it anyway in case it got cleared
      [$(`#dev-${key}-total`), $(`#dev-${key}-total-condensed`), $(`#tooltip-dev-${key}-total`)].forEach(el => {
        if (el) el.textContent = total;
      });
    });
    
    // Update total purchased (x/25 format)
    const purchased = state.devPurchased || 0;
    ['dev-purchased', 'dev-purchased-condensed', 'tooltip-dev-purchased'].forEach(id => {
      const el = $(`#${id}`);
      if (el) el.textContent = purchased;
    });
  }

  function renderDice() {
    const box = $("#dice-stats");
    if (!box) return;
    
    if (!state.dice || !state.dice.length) {
      box.textContent = "No rolls yet";
      const collapsedDiceContent = $("#dice-collapsed-tooltip-content");
      if (collapsedDiceContent) collapsedDiceContent.textContent = "No rolls yet";
    } else {
      const counts = {};
      for (let i = 2; i <= 12; i++) counts[i] = 0;
      state.dice.forEach(r => { if (counts[r] != null) counts[r]++; });
      
      let html = '<div style="width:100%;display:flex;flex-direction:column;gap:8px;padding-top:4px;">';
      html += '<div style="display:flex;justify-content:space-between;align-items:flex-end;height:120px;padding:0 4px;">';
      for (let i = 2; i <= 12; i++) {
        const h = Math.min(counts[i] * 8, 110);
        html += `<div style="display:flex;flex-direction:column;align-items:center;width:20px;">
          <div style="width:100%;height:100%;display:flex;justify-content:center;align-items:flex-end;">
            <div style="width:14px;height:${h}px;background:linear-gradient(180deg, #60a5fa, #3b82f6);
              border-radius:4px 4px 0 0;border:1px solid rgba(59,130,246,0.5);
              box-shadow:0 0 10px rgba(96,165,250,0.4);transition:height 0.2s ease;"></div>
          </div>
          <div style="font-size:10px; margin-top:3px; font-weight:600;">${i}</div>
          <div style="font-size:10px; color:#9ca3af;">${counts[i]}</div>
        </div>`;
      }
      html += `</div><div style="font-size:11px; padding-top:4px;"><strong>Total rolls:</strong> ${state.dice.length}</div>`;
      html += `<div style="font-size:11px; color:#e5e7eb;"><strong>Last 8:</strong> ${state.dice.slice(-8).join(", ")}</div></div>`;
      box.innerHTML = html;

      const collapsedDiceContent = $("#dice-collapsed-tooltip-content");
      if (collapsedDiceContent) {
        let compact = '<div style="width:100%;display:flex;flex-direction:column;gap:6px;padding-top:2px;">';
        compact += '<div style="display:flex;justify-content:space-between;align-items:flex-end;height:80px;padding:0 2px;">';
        for (let i = 2; i <= 12; i++) {
          const h = Math.min(counts[i] * 6, 72);
          compact += `<div style="display:flex;flex-direction:column;align-items:center;width:17px;">
            <div style="width:100%;height:100%;display:flex;justify-content:center;align-items:flex-end;">
              <div style="width:12px;height:${h}px;background:linear-gradient(180deg, #93c5fd, #3b82f6);border-radius:4px 4px 0 0;border:1px solid rgba(59,130,246,0.55);"></div>
            </div>
            <div style="font-size:9px; margin-top:2px; font-weight:700;">${i}</div>
          </div>`;
        }
        compact += `</div><div style="font-size:11px;"><strong>Total:</strong> ${state.dice.length}</div>`;
        compact += `<div style="font-size:10px;color:#e5e7eb;"><strong>Last 8:</strong> ${state.dice.slice(-8).join(", ")}</div></div>`;
        collapsedDiceContent.innerHTML = compact;
      }
    }
    
    ['sev-you', 'sev-opp', 'sev-you-condensed', 'sev-opp-condensed', 'dice-total-condensed'].forEach(id => {
      const el = $(`#${id}`);
      if (el) {
        el.textContent = id === 'dice-total-condensed' ? (state.dice ? state.dice.length : 0) :
                        id.includes('you') ? (state.sevensYou || 0) : (state.sevensOpp || 0);
      }
    });

    const sev4p = $("#sevens-4p-line");
    if (sev4p && state.gameMode === "4p") {
      const me = Object.values(state.players).find(p => p && p.isMe);
      const others = orderedOtherPlayers4p();
      const orderedAll = me ? [me, ...others] : others;
      const parts = orderedAll.map(p => `${coloredPlayerNameHtml(p, p.key)}: ${p.sevens || 0}`);
      sev4p.innerHTML = parts.length ? parts.join(" · ") : "—";
    }
  }

  function renderHistory() {
    const container = $("#history-list");
    if (!container) return;
    
    if (!gameHistory || !gameHistory.length) {
      container.innerHTML = '<div class="no-history">No saved games yet.<br>Click "💾 Save" to save your current game!</div>';
      return;
    }
    
    const gamesToShow = gameHistory.slice(0, MAX_DISPLAY_GAMES);
    
    container.innerHTML = gamesToShow.map(game => {
      const totalRes = Object.values(game.oppResources || {}).reduce((a, b) => a + b, 0);
      const isLocked = game.locked || false;
      const outcomeClass = game.result === "win" ? "history-win" : (game.result === "loss" ? "history-loss" : "");
      const outcomeLabel = game.result === "win" ? " (W)" : (game.result === "loss" ? " (L)" : "");
      return `<div class="history-item ${isLocked ? 'locked' : ''} ${outcomeClass}" data-game-id="${game.id}">
        <div class="history-header">
          <span>${game.myName || 'You'} vs ${game.opponentName || 'Unknown'}${outcomeLabel}</span>
          <span class="history-date">${game.date}</span>
        </div>
        <div class="history-stats">
          <div class="history-stat"><span>🎲 Rolls:</span><span>${game.diceCount || 0}</span></div>
          <div class="history-stat"><span>🃏 Dev Cards:</span><span>${game.devPurchased || 0}</span></div>
          <div class="history-stat"><span>📦 Resources:</span><span>${totalRes}</span></div>
          <div class="history-stat"><span>⚔️ Knights:</span><span>${game.devUsed?.Knight || 0}</span></div>
        </div>
        <div class="history-buttons">
          <button class="lock-btn ${isLocked ? 'locked' : ''}" data-game-id="${game.id}">${isLocked ? '🔓 Unlock' : '🔒 Lock'}</button>
          <button class="load-game" data-game-id="${game.id}">📂 Load</button>
          <button class="delete-game" data-game-id="${game.id}">🗑️ Delete</button>
        </div>
      </div>`;
    }).join('');
    
    if (gameHistory.length > MAX_DISPLAY_GAMES) {
      container.innerHTML += `<div style="text-align:center;padding:12px;opacity:0.7;font-size:11px;font-style:italic;">
        Showing ${MAX_DISPLAY_GAMES} most recent games (${gameHistory.length} total saved)
      </div>`;
    }
    
    // Attach history event handlers
    container.querySelectorAll('.lock-btn').forEach(btn => {
      btn.addEventListener('click', (e) => {
        e.stopPropagation();
        const game = gameHistory.find(g => g.id === parseInt(btn.dataset.gameId));
        if (game) {
          game.locked = !game.locked;
          saveGameHistory();
          renderHistory();
        }
      });
    });
    
    container.querySelectorAll('.load-game').forEach(btn => {
      btn.addEventListener('click', (e) => {
        e.stopPropagation();
        const game = gameHistory.find(g => g.id === parseInt(btn.dataset.gameId));
        if (game && (state.suppressConfirms || confirm(`Load game from ${game.date}?\nThis will replace your current stats.`))) {
          loadGameIntoState(game);
          renderAll();
          saveState();
          showNotification("✅ Game loaded!");
        }
      });
    });
    
    container.querySelectorAll('.delete-game').forEach(btn => {
      btn.addEventListener('click', (e) => {
        e.stopPropagation();
        const game = gameHistory.find(g => g.id === parseInt(btn.dataset.gameId));
        if (game && game.locked) {
          showNotification("⚠️ Cannot delete locked game!", "warning");
          return;
        }
        if (state.suppressConfirms || confirm("Delete this game from history?")) {
          gameHistory = gameHistory.filter(g => g.id !== parseInt(btn.dataset.gameId));
          saveGameHistory();
          renderHistory();
          showNotification("✅ Game deleted");
        }
      });
    });
  }

  function renderAll() {
    applyGameModeUI();
    renderHand();
    renderMyResources();
    renderDevs();
    renderDice();
    updateOpponentUI();
    updateUsernameUI();
  }

  function updateOpponentUI() {
    const display = $("#opp-display");
    if (display) display.textContent = state.opponentName || "—";
  }

  function updateUsernameUI() {
    const loginSection = $("#username-login-section");
    const displaySection = $("#username-display-section");
    const myDisplay = $("#my-display");
    
    if (state.myName) {
      if (loginSection) loginSection.style.display = "none";
      if (displaySection) displaySection.style.display = "block";
      if (myDisplay) myDisplay.textContent = state.myName;
    } else {
      if (loginSection) loginSection.style.display = "block";
      if (displaySection) displaySection.style.display = "none";
    }
  }

  let lastExpandedHeight = null;

  function applyCollapsed() {
    const body = $(".tracker-body-wrapper");
    const bar = $("#catan-collapsed-bar");
    const btn = $("#catan-collapse-toggle");
    const footer = $(".tracker-footer");
    
    if (!body || !bar || !btn || !footer) return;

    if (state.collapsed) {
      if (!lastExpandedHeight) lastExpandedHeight = root.getBoundingClientRect().height;
      body.style.display = "none";
      bar.style.display = "flex";
      footer.style.display = "none";
      btn.textContent = "+";
      btn.title = "Expand";
      root.style.height = "auto";
      root.style.maxHeight = "none";
    } else {
      body.style.display = "";
      bar.style.display = "none";
      footer.style.display = "";
      btn.textContent = "–";
      btn.title = "Collapse";
      if (lastExpandedHeight) root.style.height = lastExpandedHeight + "px";
      root.style.maxHeight = "80vh";
    }
    savePanelCollapsed(!!state.collapsed);
  }

  function applyMinimized() {
    const sections = {
      dice: ['dice-content', 'dice-minimize'],
      oppHand: ['opphand-content', 'opphand-minimize'],
      myRes: ['myres-content', 'myres-minimize'],
      devCards: ['dev-content', 'dev-minimize'],
      history: ['history-content', 'history-minimize']
    };
    
    Object.entries(sections).forEach(([key, [contentId, btnId]]) => {
      const content = $(`#${contentId}`);
      const btn = $(`#${btnId}`);
      if (content) content.classList.toggle('minimized', state.minimized[key]);
      if (btn) btn.textContent = state.minimized[key] ? "+" : "−";
    });
  }

  function applySectionOrder() {
    if (!state.sectionOrder || !state.sectionOrder.length) return;
    const body = $("#catan-body");
    if (!body) return;
    
    const sections = Array.from(body.querySelectorAll(".section"));
    const ordered = [];
    state.sectionOrder.forEach(text => {
      const s = sections.find(s => s.querySelector(".section-header strong")?.textContent.trim() === text);
      if (s) ordered.push(s);
    });
    sections.forEach(s => { if (!ordered.includes(s)) ordered.push(s); });
    ordered.forEach(s => body.appendChild(s));
  }

  function generateStatsText() {
    const myName = state.myName || "Me";
    const oppName = state.opponentName || "Opponent";
    const totalRolls = state.dice ? state.dice.length : 0;
    
    // Calculate dice distribution
    const diceCounts = {};
    for (let i = 2; i <= 12; i++) diceCounts[i] = 0;
    if (state.dice) {
      state.dice.forEach(r => { if (diceCounts[r] != null) diceCounts[r]++; });
    }
    
    // Find most/least rolled
    let mostRolled = 7, leastRolled = 7, maxCount = 0, minCount = Infinity;
    for (let i = 2; i <= 12; i++) {
      if (diceCounts[i] > maxCount) { maxCount = diceCounts[i]; mostRolled = i; }
      if (diceCounts[i] < minCount) { minCount = diceCounts[i]; leastRolled = i; }
    }
    
    // Resource totals
    const myTotals = RESOURCES.map(r => {
      const t = state.myTracking[r] || {};
      return `${RESOURCE_ICONS[r]} ${t.total || 0}`;
    }).join("  ");
    
    const oppTotals = RESOURCES.map(r => {
      const t = state.oppTracking[r] || {};
      return `${RESOURCE_ICONS[r]} ${t.total || 0}`;
    }).join("  ");
    
    // Dev cards used
    const devsUsed = DEV_CARD_TYPES.map(type => {
      const used = state.devUsed[type] || 0;
      if (used > 0) return `${DEV_CARD_ICONS[type]} ${used}/${DEV_CARD_TOTALS[type]}`;
      return null;
    }).filter(Boolean).join("  ") || "None";
    
    const text = `
🎲 CATAN GAME STATS 🎲
━━━━━━━━━━━━━━━━━━━━━━
👤 ${myName} vs ${oppName}
📅 ${new Date().toLocaleDateString()} ${new Date().toLocaleTimeString()}

🎲 DICE (${totalRolls} rolls)
7️⃣ Sevens: ${myName}: ${state.sevensYou || 0} | ${oppName}: ${state.sevensOpp || 0}
📈 Most rolled: ${mostRolled} (${maxCount}x)
📉 Least rolled: ${leastRolled} (${minCount}x)

📊 MY TOTAL RESOURCES
${myTotals}

👤 OPPONENT'S TOTAL RESOURCES  
${oppTotals}

🃏 DEV CARDS USED
${devsUsed}
📦 Total Purchased: ${state.devPurchased || 0}/${TOTAL_DEV_CARDS}

━━━━━━━━━━━━━━━━━━━━━━
Tracked with Catan Tracker by Smiller925
twitch.tv/Smiller925
`.trim();
    
    return text;
  }

  function copyStatsToClipboard() {
    const text = generateStatsText();
    navigator.clipboard.writeText(text).then(() => {
      showNotification("📋 Stats copied to clipboard!");
    }).catch(err => {
      console.error("[Tracker] Failed to copy:", err);
      showNotification("❌ Failed to copy stats", "error");
    });
  }

  function showNotification(message, type = "success") {
    const colors = {
      success: "linear-gradient(135deg, #10b981, #059669)",
      warning: "linear-gradient(135deg, #f59e0b, #d97706)",
      error: "linear-gradient(135deg, #ef4444, #dc2626)",
      info: "linear-gradient(135deg, #3b82f6, #2563eb)"
    };
    
    const notif = document.createElement('div');
    notif.style.cssText = `
      position: fixed;
      top: 80px;
      right: 20px;
      background: ${colors[type] || colors.success};
      color: white;
      padding: 12px 20px;
      border-radius: 10px;
      font-weight: 600;
      z-index: 999999999;
      box-shadow: 0 4px 12px rgba(0, 0, 0, 0.3);
      font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', system-ui, sans-serif;
      font-size: 13px;
    `;
    notif.textContent = message;
    document.body.appendChild(notif);
    setTimeout(() => notif.remove(), 3000);
  }

  function showLoginPopup() {
    if (state.myName) return;
    
    const popup = document.createElement('div');
    popup.style.cssText = `
      position: fixed;
      top: 50%;
      left: 50%;
      transform: translate(-50%, -50%);
      background: linear-gradient(135deg, #ef4444, #dc2626);
      color: white;
      padding: 24px 32px;
      border-radius: 12px;
      font-weight: 600;
      z-index: 999999999;
      box-shadow: 0 8px 32px rgba(0,0,0,0.4);
      text-align: center;
      font-size: 16px;
      border: 2px solid rgba(255,255,255,0.3);
      font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', system-ui, sans-serif;
    `;
    popup.innerHTML = `
      <div style="margin-bottom: 12px;">⚠️ Please Login First</div>
      <div style="font-size: 13px; opacity: 0.9; margin-bottom: 16px;">Enter your username to start tracking</div>
      <button id="popup-close" style="padding: 8px 20px; font-size: 13px; border-radius: 6px; border: none; background: white; color: #dc2626; cursor: pointer; font-weight: 700;">Got it!</button>
    `;
    document.body.appendChild(popup);
    
    popup.querySelector('#popup-close').addEventListener('click', () => popup.remove());
    setTimeout(() => popup.remove(), 4000);
  }

  // ─────────────────────────────────────────────────────────────────────────────
  // SECTION 8: GAME MANAGEMENT
  // ─────────────────────────────────────────────────────────────────────────────

  function loadGameIntoState(game) {
    state.dice = [...(game.dice || [])];
    state.sevensYou = game.sevensYou || 0;
    state.sevensOpp = game.sevensOpp || 0;
    state.devPurchased = game.devPurchased || 0;
    state.devUsed = { ...createEmptyDevUsed(), ...(game.devUsed || {}) };
    state.myResources = { ...createEmptyResources(), ...(game.myResources || {}) };
    state.resources = { ...createEmptyResources(), ...(game.oppResources || {}) };
    state.myTracking = JSON.parse(JSON.stringify(game.myTracking || createResourceTracking()));
    state.oppTracking = JSON.parse(JSON.stringify(game.oppTracking || createResourceTracking()));
    state.opponentName = game.opponentName || "";
    state.startingResourcesCount = 0;
  }

  function saveCurrentGame(forceSave = false) {
    const hasData = (state.dice && state.dice.length > 5) || state.devPurchased > 0 ||
                    Object.values(state.resources).some(v => v > 2) ||
                    Object.values(state.myResources).some(v => v > 2);
    
    if (!hasData && !forceSave) return false;

    const myLower = (state.myName || "").trim().toLowerCase();
    const winnerLower = (state.lastWinnerName || "").trim().toLowerCase();
    let result = null;
    if (winnerLower) {
      result = (winnerLower === "you" || (myLower && winnerLower === myLower)) ? "win" : "loss";
    }
    
    const newGame = {
      id: Date.now(),
      date: new Date().toLocaleString(),
      myName: state.myName || "",
      opponentName: state.opponentName || "",
      dice: [...(state.dice || [])],
      diceCount: state.dice ? state.dice.length : 0,
      sevensYou: state.sevensYou || 0,
      sevensOpp: state.sevensOpp || 0,
      devPurchased: state.devPurchased || 0,
      devUsed: { ...(state.devUsed || {}) },
      myResources: { ...(state.myResources || {}) },
      oppResources: { ...(state.resources || {}) },
      myTracking: JSON.parse(JSON.stringify(state.myTracking || createResourceTracking())),
      oppTracking: JSON.parse(JSON.stringify(state.oppTracking || createResourceTracking())),
      result,
      winnerName: state.lastWinnerName || "",
      winningPoints: typeof state.lastWinningPoints === "number" ? state.lastWinningPoints : null,
      locked: false
    };
    
    gameHistory.unshift(newGame);
    
    // Auto-delete oldest unlocked games if over limit
    const unlockedGames = gameHistory.filter(g => !g.locked);
    if (unlockedGames.length > MAX_UNLOCKED_GAMES) {
      const gamesToDelete = unlockedGames.slice(MAX_UNLOCKED_GAMES);
      gamesToDelete.forEach(game => {
        const index = gameHistory.findIndex(g => g.id === game.id);
        if (index !== -1) {
          gameHistory.splice(index, 1);
          console.log(`[Tracker] Auto-deleted old game from ${game.date}`);
        }
      });
    }
    
    saveGameHistory();
    renderHistory();
    return true;
  }

  function completeGameReset() {
    console.log("[Tracker] ===== COMPLETE GAME RESET =====");
    
    const savedMyName = state.myName;
    const savedOpponentName = state.opponentManual ? state.opponentName : "";
    const savedOpponentManual = state.opponentManual;
    const savedSectionOrder = state.sectionOrder;
    const savedMinimized = state.minimized;
    const savedCollapsed = state.collapsed;
    const savedSuppressConfirms = state.suppressConfirms;
    const savedGameMode = state.gameMode;
    
    state = createDefaultState();
    state.myName = savedMyName;
    state.opponentName = savedOpponentName;
    state.opponentManual = savedOpponentManual;
    state.sectionOrder = savedSectionOrder;
    state.minimized = savedMinimized;
    state.collapsed = savedCollapsed;
    state.suppressConfirms = savedSuppressConfirms;
    state.gameMode = savedGameMode === "4p" ? "4p" : "1v1";
    
    processedIndexes.clear();
    
    renderAll();
    applyCollapsed();
    applyMinimized();
    saveState();
    
    console.log("[Tracker] Reset complete");
  }

  function autoSaveAndReset() {
    const saved = saveCurrentGame();
    completeGameReset();
    
    if (saved) {
      showNotification("✅ Previous game saved! New game started.");
    }
  }

// ─────────────────────────────────────────────────────────────────────────────
  // SECTION 9: LOG MESSAGE HANDLER
  // ─────────────────────────────────────────────────────────────────────────────

  function handleNewGameTransition() {
    console.log("[Tracker] ===== NEW GAME TRANSITION =====");
    
    // Save current game if there's meaningful data
    const hasData = (state.dice && state.dice.length > 5) || state.devPurchased > 0 ||
                    Object.values(state.resources).some(v => v > 2) ||
                    Object.values(state.myResources).some(v => v > 2);
    
    if (hasData && !state.gameSavedAfterWin) {
      saveCurrentGame();
      showNotification("✅ Previous game saved! New game detected.");
    } else if (hasData && state.gameSavedAfterWin) {
      showNotification("🆕 New game detected!");
    } else {
      showNotification("🆕 New game detected!");
    }
    
    // Reset for new game but keep username and preferences
    const savedMyName = state.myName;
    const savedOpponentManual = state.opponentManual;
    const savedOpponentName = state.opponentManual ? state.opponentName : "";
    const savedSectionOrder = state.sectionOrder;
    const savedMinimized = state.minimized;
    const savedCollapsed = state.collapsed;
    const savedSuppressConfirms = state.suppressConfirms;
    const savedGameMode = state.gameMode;
    
    // Full reset
    state = createDefaultState();
    state.myName = savedMyName;
    state.opponentManual = savedOpponentManual;
    state.opponentName = savedOpponentName;
    state.sectionOrder = savedSectionOrder;
    state.minimized = savedMinimized;
    state.collapsed = savedCollapsed;
    state.suppressConfirms = savedSuppressConfirms;
    state.gameMode = savedGameMode === "4p" ? "4p" : "1v1";
    state.gameSavedAfterWin = false;
    
    // Clear processed indexes so we process new game fresh
    processedIndexes.clear();
    
    // Clear global processed messages
    GLOBAL_PROCESSED_MESSAGES.clear();
    saveGlobalProcessedMessages();
    
    renderAll();
    applyCollapsed();
    applyMinimized();
    saveState();
    
    console.log("[Tracker] New game started, waiting for opponent detection...");
  }

  function handleLogLine4p(text, node, messageId) {
    const lower = text.toLowerCase();
    const myLower = (state.myName || "").trim().toLowerCase();
    const rowText = getLogRowText(node, text);
    const rowLower = rowText.toLowerCase();

    syncPlayerColorsFromLogNode(node);

    if (lower.includes("won the game")) {
      markGameWinnerFromLog(text);
      state.gameEnded = true;
      state.gameInProgress = false;
      if (!state.gameSavedAfterWin) {
        const saved = saveCurrentGame(true);
        if (saved) {
          state.gameSavedAfterWin = true;
          showNotification("✅ Game saved. Waiting for next game start...");
        }
      }
      saveState();
      return;
    }

    if (lower.includes("placed a settlement") || lower.includes("placed a starting settlement")) {
      // Do not reset yet; wait until starting resources appear for the next game.
      state.gameInProgress = true;
      saveState();
    }

    if (lower.includes("received starting resources")) {
      if (state.gameEnded) {
        handleNewGameTransition();
      }
      const resources = imgsToResources(node);
      const match = text.match(/^(.+?)\s+received starting resources/i);
      if (match) {
        const playerName = match[1].trim();
        const nl = playerName.toLowerCase();
        const isMe = nl === "you" || nl === myLower;
        const p = ensurePlayerRecord(isMe ? state.myName : playerName, isMe);
        if (p && resources.length > 0) {
          resources.forEach(r => trackPlayerResource4p(p.key, r, 1, "starting"));
        }
      }
      state.startingResourcesCount++;
      if (!isRescanning) {
        renderHand();
        renderMyResources();
        saveState();
      }
      return;
    }

    if (text.includes("rolled")) {
      const diceVals = imgsToDice(node);
      if (diceVals.length >= 2) {
        const total = diceVals[0] + diceVals[1];
        if (!state.dice) state.dice = [];
        state.dice.push(total);
        if (total === 7) {
          const actor = getActorFromLogLine(text);
          if (actor) actor.sevens = (actor.sevens || 0) + 1;
        }
        if (!isRescanning) {
          renderDice();
          saveState();
        }
      }
    }

    if (lower.includes("stole") && /stole\s+\d+/.test(lower)) {
      const resources = imgsToResources(node);
      if (resources.length > 0) {
        const res = resources[0];
        const actor = getActorFromLogLine(text);
        if (actor) {
          let totalTaken = 0;
          Object.values(state.players).forEach(p => {
            if (p.key === actor.key) return;
            const have = p.resources[res] || 0;
            if (have > 0) {
              trackPlayerResource4p(p.key, res, -have, "stolen");
              totalTaken += have;
            }
          });
          if (totalTaken > 0) trackPlayerResource4p(actor.key, res, totalTaken, "stolen");
        }
        if (!isRescanning) {
          renderHand();
          renderMyResources();
          saveState();
        }
      }
      return;
    }

    const usedDevCardType = detectPlayedDevCard(lower, node);
    if (usedDevCardType) {
      if (!state.devUsed) state.devUsed = createEmptyDevUsed();
      state.devUsed[usedDevCardType]++;
      const devActor = getActorFromLogLine(text);
      if (devActor) devActor.devCardsHeld = Math.max(0, (devActor.devCardsHeld || 0) - 1);
      if (!isRescanning) {
        renderDevs();
        renderHand();
        saveState();
      }
    }

    if (lower.includes("stole") && lower.includes("from you")) {
      const resources = imgsToResources(node);
      const thief = getActorFromLogLine(text);
      const me = ensurePlayerRecord(state.myName, true);
      if (thief && me && thief.key !== me.key) {
        if (resources.length > 0) {
          resources.forEach(r => {
            trackPlayerResource4p(thief.key, r, 1, "stolen");
            trackPlayerResource4p(me.key, r, -1, "stolen");
          });
        } else {
          registerBlindSteal(thief.key, me.key);
        }
      }
    } else if (lower.startsWith("you stole")) {
      const resources = imgsToResources(node);
      const me = ensurePlayerRecord(state.myName, true);
      const vm = text.match(/\bfrom\s+(.+?)(?:\.|$)/i);
      const victimKey = vm ? resolveNameToKey(vm[1]) : null;
      if (me && victimKey && me.key !== victimKey) {
        if (resources.length > 0) {
          resources.forEach(r => {
            trackPlayerResource4p(me.key, r, 1, "stolen");
            trackPlayerResource4p(victimKey, r, -1, "stolen");
          });
        } else {
          registerBlindSteal(me.key, victimKey);
        }
      }
    } else if (lower.includes("stole") && lower.includes("from") && !lower.includes("bank")) {
      const pair = parseRobberThiefVictim(text, lower);
      if (pair) {
        const thiefKey = resolveNameToKey(pair.thief);
        const victimKey = resolveNameToKey(pair.victim);
        if (thiefKey && victimKey && thiefKey !== victimKey) {
          const resources = imgsToResources(node);
          if (resources.length > 0) {
            resources.forEach(r => {
              trackPlayerResource4p(thiefKey, r, 1, "stolen");
              trackPlayerResource4p(victimKey, r, -1, "stolen");
            });
          } else {
            registerBlindSteal(thiefKey, victimKey);
          }
        }
      }
    }

    if (applyColonistGaveGotFromTrade4p(text, node, rowText, rowLower)) {
      if (!isRescanning) {
        renderHand();
        renderMyResources();
        saveState();
      }
      return;
    }

    if (applyColonistPlayerTrade4p(text, node, rowText, rowLower)) {
      if (!isRescanning) {
        renderHand();
        renderMyResources();
        saveState();
      }
      return;
    }

    if (tryApplyGotLineAsPlayerTrade4p(text, node, rowText, rowLower)) {
      if (!isRescanning) {
        renderHand();
        renderMyResources();
        saveState();
      }
      return;
    }

    if (/\sgot\b/i.test(text)) {
      const resources = imgsToResources(node);
      const actor = getActorFromLogLine(text);
      if (actor && resources.length > 0) {
        resources.forEach(r => trackPlayerResource4p(actor.key, r, 1, "rolled"));
        if (!isRescanning) {
          renderHand();
          renderMyResources();
          saveState();
        }
      }
    }

    if (lower.includes("took from bank") && !lower.includes("gave bank")) {
      const resources = imgsToResources(node);
      const actor = getActorFromLogLine(text);
      if (actor && resources.length > 0) {
        resources.forEach(r => trackPlayerResource4p(actor.key, r, 1, "stolen"));
        if (!isRescanning) {
          renderHand();
          renderMyResources();
          saveState();
        }
      }
      return;
    }

    if (lower.includes("discarded")) {
      const resources = imgsToResources(node);
      const actor = getActorFromLogLine(text);
      if (actor && resources.length > 0) {
        resources.forEach(r => trackPlayerResource4p(actor.key, r, -1, "discarded"));
        if (!isRescanning) {
          renderHand();
          renderMyResources();
          saveState();
        }
      }
    }

    if (rowLower.includes("gave bank") && rowLower.includes("and took")) {
      const given = [], taken = [];
      let onGiven = true;
      function walk(n) {
        if (n.nodeType === 3 && /and took/i.test(n.textContent || "")) onGiven = false;
        else if (n.nodeType === 1 && n.tagName === "IMG") {
          const key = imgAltToResourceKey(n);
          if (key) (onGiven ? given : taken).push(key);
        }
        if (n.childNodes) n.childNodes.forEach(walk);
      }
      walk(node);
      const actor = getActorFromLogLine(text);
      if (actor && (given.length || taken.length)) {
        given.forEach(r => trackPlayerResource4p(actor.key, r, -1, "bankTrade"));
        taken.forEach(r => trackPlayerResource4p(actor.key, r, 1, "bankTrade"));
      }
    }

    if (lower.includes("bought")) {
      if (Array.from(node.querySelectorAll("img[alt]")).some(img => /Development Card/i.test(img.getAttribute("alt") || ""))) {
        const actor = getActorFromLogLine(text);
        if (actor) {
          ["wool", "grain", "ore"].forEach(r => trackPlayerResource4p(actor.key, r, -1, "rolled"));
          state.devPurchased++;
          actor.devBuys = (actor.devBuys || 0) + 1;
          actor.devCardsHeld = (actor.devCardsHeld || 0) + 1;
          if (!isRescanning) {
            renderDevs();
            renderHand();
          }
        }
      }
    }

    if (lower.includes("built")) {
      const actor = getActorFromLogLine(text);
      if (actor) {
        if (lower.includes("road")) ["brick", "lumber"].forEach(r => trackPlayerResource4p(actor.key, r, -1, "rolled"));
        if (lower.includes("settlement")) ["brick", "lumber", "wool", "grain"].forEach(r => trackPlayerResource4p(actor.key, r, -1, "rolled"));
        if (lower.includes("city")) {
          trackPlayerResource4p(actor.key, "grain", -2, "rolled");
          trackPlayerResource4p(actor.key, "ore", -3, "rolled");
        }
      }
    }
  }

  function handleLogLine(text, node, messageId) {
    const lower = text.toLowerCase();
    const myLower = (state.myName || "").trim().toLowerCase();
    const oppLower = (state.opponentName || "").trim().toLowerCase();
    const rowText = getLogRowText(node, text);
    const rowLower = rowText.toLowerCase();

    // Require login for most actions
    if (!state.myName) {
      if (lower.includes("rolled") || 
          lower.includes("received starting resources") || 
          lower.includes("got") ||
          lower.includes("built") ||
          lower.includes("placed")) {
        showLoginPopup();
        return;
      }
    }

    if (state.gameMode === "4p" && state.myName) {
      handleLogLine4p(text, node, messageId);
      return;
    }

    // GAME WIN DETECTION - Mark game as ended
    if (lower.includes("won the game")) {
      console.log("[Tracker] 🏆 GAME END DETECTED - Waiting for new game...");
      markGameWinnerFromLog(text);
      state.gameEnded = true;
      state.gameInProgress = false;
      if (!state.gameSavedAfterWin) {
        const saved = saveCurrentGame(true);
        if (saved) {
          state.gameSavedAfterWin = true;
          showNotification("✅ Game saved. Waiting for next game start...");
        }
      }
      saveState();
      return;
    }

    // SETTLEMENT PLACEMENT - Triggers new game if previous game ended
    if (lower.includes("placed a settlement") || lower.includes("placed a starting settlement")) {
      console.log("[Tracker] 🏠 Settlement placed detected. gameEnded:", state.gameEnded);

      // Mark game as in progress
      state.gameInProgress = true;
      saveState();
      
      // Don't return - continue processing to potentially detect opponent
    }

    // TRY TO DETECT OPPONENT FROM ANY MESSAGE (fallback detection)
    if (!state.opponentName && !state.opponentManual && state.myName) {
      const detectedOpp = tryDetectOpponentFromMessage(text);
      if (detectedOpp) {
        state.opponentName = detectedOpp;
        updateOpponentUI();
        saveState();
        console.log("[Tracker] ✅ Opponent auto-detected from message:", detectedOpp);
      }
    }

    // STARTING RESOURCES
    if (lower.includes("received starting resources")) {
      if (state.gameEnded) {
        console.log("[Tracker] 🆕 NEW GAME STARTING - Starting resources detected after game end");
        handleNewGameTransition();
      }
      console.log("[Tracker] 📦 STARTING RESOURCES MESSAGE DETECTED:", text);
      console.log("[Tracker] Node innerHTML:", node.innerHTML ? node.innerHTML.substring(0, 200) : "N/A");
      
      // Try to find resources from the node
      const resources = imgsToResources(node);
      console.log("[Tracker] Resources found:", resources);
      
      const match = text.match(/^(.+?)\s+received starting resources/i);
      
      if (match) {
        const playerName = match[1].trim();
        const playerLower = playerName.toLowerCase();
        
        const isMe = playerLower === "you" || playerLower === myLower;
        const isOpp = !isMe && playerLower !== myLower;
        
        console.log("[Tracker] Player:", playerName, "isMe:", isMe, "isOpp:", isOpp, "myLower:", myLower);
        
        state.startingResourcesCount++;
        console.log(`[Tracker] ✅ Starting resources #${state.startingResourcesCount} - ${playerName} got ${resources.length} resources:`, resources);
        
        // Auto-detect opponent
        if (isOpp && !state.opponentName && !state.opponentManual) {
          state.opponentName = playerName;
          updateOpponentUI();
          saveState();
          console.log("[Tracker] 🎯 Auto-detected opponent:", state.opponentName);
        }
        
        // Track resources
        if (isOpp && resources.length > 0) {
          console.log("[Tracker] Adding starting resources to OPPONENT:", resources);
          resources.forEach(r => trackResource("opp", r, 1, "starting"));
        } else if (isMe && resources.length > 0) {
          console.log("[Tracker] Adding starting resources to ME:", resources);
          resources.forEach(r => trackResource("me", r, 1, "starting"));
        } else if (resources.length === 0) {
          console.log("[Tracker] ⚠️ NO RESOURCES FOUND in starting resources message!");
        }
      } else {
        console.log("[Tracker] ⚠️ Could not parse player name from:", text);
      }
      
      if (!isRescanning) {
        renderHand();
        renderMyResources();
        saveState();
      }
      return;
    }

    // DICE ROLLS
    if (text.includes("rolled")) {
      const diceVals = imgsToDice(node);
      if (diceVals.length >= 2) {
        const total = diceVals[0] + diceVals[1];
        if (!state.dice) state.dice = [];
        state.dice.push(total);
        if (total === 7) {
          // Re-read oppLower
          const currentOppLower = (state.opponentName || "").trim().toLowerCase();
          if (text.startsWith("You ") || (myLower && lower.startsWith(myLower + " "))) state.sevensYou++;
          else if (currentOppLower && lower.startsWith(currentOppLower + " ")) state.sevensOpp++;
        }
        if (!isRescanning) {
          renderDice();
          saveState();
        }
      }
    }

    // MONOPOLY STEAL
    if (lower.includes("stole") && /stole\s+\d+/.test(lower)) {
      const match = text.match(/stole\s+(\d+)/i);
      const resources = imgsToResources(node);
      
      if (match && resources.length > 0) {
        const amount = parseInt(match[1], 10);
        const res = resources[0];
        
        // Re-read oppLower
        const currentOppLower = (state.opponentName || "").trim().toLowerCase();
        
        const isMe = text.startsWith("You ") || (myLower && lower.startsWith(myLower + " "));
        const isOpp = currentOppLower && lower.startsWith(currentOppLower + " ");
        
        console.log("[Tracker] Monopoly steal:", { isMe, isOpp, amount, res });
        
        if (isOpp) {
          state.resources[res] = (state.resources[res] || 0) + amount;
          if (!state.oppTracking[res]) state.oppTracking[res] = { starting: 0, rolled: 0, stolen: 0, bankTrade: 0, discarded: 0, total: 0 };
          state.oppTracking[res].stolen += amount;
          state.oppTracking[res].total += amount;
          state.myResources[res] = Math.max(0, (state.myResources[res] || 0) - amount);
          if (!isRescanning) {
            renderHand();
            renderMyResources();
            saveState();
          }
        } else if (isMe) {
          state.myResources[res] = (state.myResources[res] || 0) + amount;
          if (!state.myTracking[res]) state.myTracking[res] = { starting: 0, rolled: 0, stolen: 0, bankTrade: 0, discarded: 0, total: 0 };
          state.myTracking[res].stolen += amount;
          state.myTracking[res].total += amount;
          state.resources[res] = Math.max(0, (state.resources[res] || 0) - amount);
          if (!isRescanning) {
            renderHand();
            renderMyResources();
            saveState();
          }
        }
        return;
      }
    }

// DEV CARDS USED
    const usedDevCardType = detectPlayedDevCard(lower, node);
    if (usedDevCardType) {
      if (!state.devUsed) state.devUsed = createEmptyDevUsed();
      state.devUsed[usedDevCardType]++;
      console.log(`[Tracker] ${usedDevCardType} card used, total:`, state.devUsed[usedDevCardType]);
      // Note: Victory Points are revealed at game end, not "used"
      
      if (!isRescanning) {
        renderDevs();
        saveState();
      }
    }

    // ROBBER STEALS
    if (lower.includes("stole") && lower.includes("from you")) {
      const resources = imgsToResources(node);
      console.log("[Tracker] Robber stole from me:", resources);
      resources.forEach(r => {
        trackResource("opp", r, 1, "stolen");
        trackResource("me", r, -1, "stolen");
      });
      if (!isRescanning && resources.length > 0) {
        renderHand();
        renderMyResources();
        saveState();
      }
    } else if (lower.startsWith("you stole")) {
      const resources = imgsToResources(node);
      console.log("[Tracker] I stole:", resources);
      resources.forEach(r => {
        trackResource("me", r, 1, "stolen");
        trackResource("opp", r, -1, "stolen");
      });
      if (!isRescanning && resources.length > 0) {
        renderHand();
        renderMyResources();
        saveState();
      }
    }

    if (applyColonistGaveGotFromTrade1v1(text, node, rowText, rowLower, myLower)) {
      if (!isRescanning) {
        renderHand();
        renderMyResources();
        saveState();
      }
      return;
    }

    if (applyColonistPlayerTrade1v1(text, node, rowText, rowLower, myLower)) {
      if (!isRescanning) {
        renderHand();
        renderMyResources();
        saveState();
      }
      return;
    }

    if (tryApplyGotLineAsPlayerTrade1v1(text, node, rowText, rowLower, myLower)) {
      if (!isRescanning) {
        renderHand();
        renderMyResources();
        saveState();
      }
      return;
    }

    // GOT RESOURCES (main tracking from dice rolls)
    if (/\sgot\b/i.test(text)) {
      const resources = imgsToResources(node);
      
      // Re-read oppLower in case we just detected the opponent above
      const currentOppLower = (state.opponentName || "").trim().toLowerCase();
      
      const isMe = text.startsWith("You ") || (myLower && lower.startsWith(myLower + " "));
      
      let isOpp = false;
      if (currentOppLower) {
        // Check if message starts with opponent name
        isOpp = lower.startsWith(currentOppLower + " ");
      }
      
      console.log("[Tracker] 'got' message:", {
        text: text.substring(0, 50),
        isMe: isMe,
        isOpp: isOpp,
        currentOppLower: currentOppLower,
        resources: resources
      });
      
      if (isOpp && resources.length > 0) {
        console.log("[Tracker] ✅ Adding to OPPONENT:", resources);
        resources.forEach(r => trackResource("opp", r, 1, "rolled"));
        if (!isRescanning) {
          renderHand();
          saveState();
        }
      } else if (isMe && resources.length > 0) {
        console.log("[Tracker] ✅ Adding to ME:", resources);
        resources.forEach(r => trackResource("me", r, 1, "rolled"));
        if (!isRescanning) {
          renderMyResources();
          saveState();
        }
      } else if (resources.length > 0 && !isMe && !isOpp) {
        console.log("[Tracker] ⚠️ Got resources but couldn't determine owner! oppLower='" + currentOppLower + "'");
      }
    }

    // TOOK FROM BANK (Year of Plenty resources)
    if (lower.includes("took from bank") && !lower.includes("gave bank")) {
      const resources = imgsToResources(node);
      
      console.log("[Tracker] 'took from bank' detected:", text.substring(0, 60));
      console.log("[Tracker] Resources found:", resources);
      
      // Re-read oppLower
      const currentOppLower = (state.opponentName || "").trim().toLowerCase();
      
      const isMe = text.startsWith("You ") || (myLower && lower.startsWith(myLower + " "));
      const isOpp = currentOppLower && lower.startsWith(currentOppLower + " ");
      
      console.log("[Tracker] Took from bank:", { isMe, isOpp, resources });
      
      if (isOpp && resources.length > 0) {
        console.log("[Tracker] ✅ Adding Year of Plenty resources to OPPONENT:", resources);
        resources.forEach(r => trackResource("opp", r, 1, "stolen")); // Using "stolen" as it's a free gain
        if (!isRescanning) {
          renderHand();
          saveState();
        }
      } else if (isMe && resources.length > 0) {
        console.log("[Tracker] ✅ Adding Year of Plenty resources to ME:", resources);
        resources.forEach(r => trackResource("me", r, 1, "stolen")); // Using "stolen" as it's a free gain
        if (!isRescanning) {
          renderMyResources();
          saveState();
        }
      }
       return; 
    }

    // DISCARDS
    if (lower.includes("discarded")) {
      // ... existing code stays the same ...
    }

    // DISCARDS
    if (lower.includes("discarded")) {
      const resources = imgsToResources(node);
      // Re-read oppLower
      const currentOppLower = (state.opponentName || "").trim().toLowerCase();
      
      const isMe = text.startsWith("You ") || (myLower && lower.startsWith(myLower + " "));
      const isOpp = currentOppLower && lower.startsWith(currentOppLower + " ");
      
      console.log("[Tracker] Discard:", { isMe, isOpp, resources });
      
      if (isOpp) {
        resources.forEach(r => {
          state.resources[r] = Math.max(0, (state.resources[r] || 0) - 1);
          if (!state.oppTracking[r]) state.oppTracking[r] = { starting: 0, rolled: 0, stolen: 0, bankTrade: 0, discarded: 0, total: 0 };
          state.oppTracking[r].discarded += 1;
        });
        if (!isRescanning) {
          renderHand();
          saveState();
        }
      } else if (isMe) {
        resources.forEach(r => {
          state.myResources[r] = Math.max(0, (state.myResources[r] || 0) - 1);
          if (!state.myTracking[r]) state.myTracking[r] = { starting: 0, rolled: 0, stolen: 0, bankTrade: 0, discarded: 0, total: 0 };
          state.myTracking[r].discarded += 1;
        });
        if (!isRescanning) {
          renderMyResources();
          saveState();
        }
      }
    }

    // BANK TRADES
    if (rowLower.includes("gave bank") && rowLower.includes("and took")) {
      const given = [], taken = [];
      let onGiven = true;
      
      function walk(n) {
        if (n.nodeType === 3 && /and took/i.test(n.textContent || "")) onGiven = false;
        else if (n.nodeType === 1 && n.tagName === "IMG") {
          const key = imgAltToResourceKey(n);
          if (key) (onGiven ? given : taken).push(key);
        }
        if (n.childNodes) n.childNodes.forEach(walk);
      }
      walk(node);
      
      // Re-read oppLower
      const currentOppLower = (state.opponentName || "").trim().toLowerCase();
      
      const isMe = rowText.startsWith("You ") || (myLower && rowLower.startsWith(myLower + " "));
      const isOpp = currentOppLower && rowLower.startsWith(currentOppLower + " ");
      
      console.log("[Tracker] Bank trade:", { isMe, isOpp, given, taken });
      
      if (isOpp) {
        given.forEach(r => trackResource("opp", r, -1, "bankTrade"));
        taken.forEach(r => trackResource("opp", r, 1, "bankTrade"));
      } else if (isMe) {
        given.forEach(r => trackResource("me", r, -1, "bankTrade"));
        taken.forEach(r => trackResource("me", r, 1, "bankTrade"));
      }
    }

    // DEV CARD PURCHASES
    if (lower.includes("bought")) {
      if (Array.from(node.querySelectorAll("img[alt]")).some(img => /Development Card/i.test(img.getAttribute("alt") || ""))) {
        // Re-read oppLower
        const currentOppLower = (state.opponentName || "").trim().toLowerCase();
        
        const isMe = text.startsWith("You ") || (myLower && lower.startsWith(myLower + " "));
        const isOpp = currentOppLower && lower.startsWith(currentOppLower + " ");
        
        console.log("[Tracker] Dev card bought:", { isMe, isOpp });
        
        if (isOpp) {
          ['wool', 'grain', 'ore'].forEach(r => trackResource("opp", r, -1, "rolled"));
          state.devPurchased++;
          if (!isRescanning) renderDevs();
        } else if (isMe) {
          ['wool', 'grain', 'ore'].forEach(r => trackResource("me", r, -1, "rolled"));
          state.devPurchased++;
          if (!isRescanning) renderDevs();
        }
      }
    }

    // BUILDS
    if (lower.includes("built")) {
      // Re-read oppLower in case we just detected the opponent
      const currentOppLower = (state.opponentName || "").trim().toLowerCase();
      
      const isMe = text.startsWith("You ") || (myLower && lower.startsWith(myLower + " "));
      const isOpp = currentOppLower && lower.startsWith(currentOppLower + " ");
      
      console.log("[Tracker] Built:", { isMe, isOpp, text: text.substring(0, 40) });
      
      if (isOpp) {
        if (lower.includes("road")) {
          ['brick', 'lumber'].forEach(r => trackResource("opp", r, -1, "rolled"));
        }
        if (lower.includes("settlement")) {
          ['brick', 'lumber', 'wool', 'grain'].forEach(r => trackResource("opp", r, -1, "rolled"));
        }
        if (lower.includes("city")) {
          trackResource("opp", "grain", -2, "rolled");
          trackResource("opp", "ore", -3, "rolled");
        }
      } else if (isMe) {
        if (lower.includes("road")) {
          ['brick', 'lumber'].forEach(r => trackResource("me", r, -1, "rolled"));
        }
        if (lower.includes("settlement")) {
          ['brick', 'lumber', 'wool', 'grain'].forEach(r => trackResource("me", r, -1, "rolled"));
        }
        if (lower.includes("city")) {
          trackResource("me", "grain", -2, "rolled");
          trackResource("me", "ore", -3, "rolled");
        }
      }
    }
  }
// ─────────────────────────────────────────────────────────────────────────────
  // SECTION 10: LOG SCANNER & RESCAN
  // ─────────────────────────────────────────────────────────────────────────────

  function scanLog() {
    
    const container = queryWithFallbacks(document, COLONIST_SELECTORS.virtualScroller);
    if (!container) return;
    
    const items = queryAllWithFallbacks(container, COLONIST_SELECTORS.scrollItemContainer);
    
    items.forEach(item => {
      const idx = item.getAttribute("data-index");
      if (!idx || processedIndexes.has(idx)) return;
      
      const feed = queryWithFallbacks(item, COLONIST_SELECTORS.feedMessage);
      if (!feed) { processedIndexes.add(idx); return; }
      
      const span = queryWithFallbacks(feed, COLONIST_SELECTORS.messagePart) || feed;
      const text = (span.innerText || span.textContent || "").trim();
      if (!text) { processedIndexes.add(idx); return; }
      
      processedIndexes.add(idx);
      try {
        // Pass the ITEM (which contains images) not just the feed span
        handleLogLine(text, item, idx);
      } catch (e) {
        console.warn("[Tracker] Error:", e);
      }
    });
  }

  function rescanEntireLog() {
    console.log("[Tracker] ===== RESCAN LOG STARTED =====");
    
    if (!state.myName) {
      showNotification("⚠️ Please login first!", "warning");
      return;
    }
    
    const progressNotif = document.createElement('div');
    progressNotif.id = 'rescan-progress';
    progressNotif.style.cssText = `
      position: fixed;
      top: 50%;
      left: 50%;
      transform: translate(-50%, -50%);
      background: linear-gradient(135deg, #8b5cf6, #7c3aed);
      color: white;
      padding: 24px 36px;
      border-radius: 12px;
      font-weight: 600;
      z-index: 999999999;
      box-shadow: 0 8px 32px rgba(0,0,0,0.4);
      text-align: center;
      font-size: 15px;
      border: 2px solid rgba(255,255,255,0.3);
      max-width: 400px;
      font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', system-ui, sans-serif;
    `;
    progressNotif.innerHTML = `
      <div style="margin-bottom: 16px; font-size: 18px;">🔄 Rescan Instructions</div>
      <div style="font-size: 13px; line-height: 1.6; margin-bottom: 16px; opacity: 0.95;">
        <strong>1.</strong> Scroll the game log to the <strong>TOP</strong><br>
        <strong>2.</strong> Slowly scroll <strong>DOWN</strong> through entire log<br>
        <strong>3.</strong> Click "Done Scrolling" when at bottom
      </div>
      <div id="rescan-status" style="font-size: 12px; opacity: 0.8; margin-bottom: 12px;">
        Messages found: <strong id="message-count">0</strong>
      </div>
      <div style="display: flex; gap: 8px; justify-content: center;">
        <button id="rescan-done-btn" style="padding: 10px 20px; font-size: 13px; background: #10b981; color: white; border: none; border-radius: 6px; cursor: pointer; font-weight: 700;">
          ✅ Done Scrolling
        </button>
        <button id="rescan-cancel-btn" style="padding: 10px 20px; font-size: 13px; background: #ef4444; color: white; border: none; border-radius: 6px; cursor: pointer; font-weight: 700;">
          ❌ Cancel
        </button>
      </div>
    `;
    document.body.appendChild(progressNotif);
    
    const savedMyName = state.myName;
    const savedOpponentName = state.opponentManual ? state.opponentName : "";
    const savedOpponentManual = state.opponentManual;
    
    const container = queryWithFallbacks(document, COLONIST_SELECTORS.virtualScroller);
    if (!container) {
      progressNotif.remove();
      showNotification("⚠️ Could not find game log!", "error");
      return;
    }
    
    processedIndexes.clear();
    
    let allMessages = [];
    const messageCountEl = document.getElementById('message-count');
    
    const collectInterval = setInterval(() => {
      const items = queryAllWithFallbacks(container, COLONIST_SELECTORS.scrollItemContainer);
      items.forEach(item => {
        const idx = item.getAttribute("data-index");
        if (idx && !allMessages.find(m => m.idx === idx)) {
          const feed = queryWithFallbacks(item, COLONIST_SELECTORS.feedMessage);
          if (feed) {
            const span = queryWithFallbacks(feed, COLONIST_SELECTORS.messagePart) || feed;
            const text = (span.innerText || span.textContent || "").trim();
            if (text) {
              // Store the full item element for image parsing
              allMessages.push({ idx, text, node: item });
              if (messageCountEl) messageCountEl.textContent = allMessages.length;
            }
          }
        }
      });
    }, TIMING.rescanCollectInterval);
    
    document.getElementById('rescan-cancel-btn').addEventListener('click', () => {
      clearInterval(collectInterval);
      progressNotif.remove();
      console.log("[Tracker] Rescan cancelled");
    });
    
    document.getElementById('rescan-done-btn').addEventListener('click', () => {
      clearInterval(collectInterval);
      
      // Final collection pass
      const items = queryAllWithFallbacks(container, COLONIST_SELECTORS.scrollItemContainer);
      items.forEach(item => {
        const idx = item.getAttribute("data-index");
        if (idx && !allMessages.find(m => m.idx === idx)) {
          const feed = queryWithFallbacks(item, COLONIST_SELECTORS.feedMessage);
          if (feed) {
            const span = queryWithFallbacks(feed, COLONIST_SELECTORS.messagePart) || feed;
            const text = (span.innerText || span.textContent || "").trim();
            if (text) {
              // Store full item element for image parsing
              allMessages.push({ idx, text, node: item });
            }
          }
        }
      });
      
      if (allMessages.length === 0) {
        alert("⚠️ No messages collected! Make sure you scrolled through the log.");
        progressNotif.remove();
        return;
      }
      
      document.getElementById('rescan-status').textContent = `Processing ${allMessages.length} messages...`;
      document.getElementById('rescan-done-btn').remove();
      document.getElementById('rescan-cancel-btn').remove();
      
      // Reset game state
      state.resources = createEmptyResources();
      state.myResources = createEmptyResources();
      state.oppTracking = createResourceTracking();
      state.myTracking = createResourceTracking();
      state.dice = [];
      state.sevensYou = 0;
      state.sevensOpp = 0;
      state.devUsed = createEmptyDevUsed();
      state.devPurchased = 0;
      state.startingResourcesCount = 0;
      state.players = {};
      state.blindSteals = [];
      state.nextBlindStealId = 1;
      
      // Restore user/opponent info
      state.myName = savedMyName;
      state.opponentName = savedOpponentName;
      state.opponentManual = savedOpponentManual;
      
      // Clear global processed messages for rescan
      GLOBAL_PROCESSED_MESSAGES.clear();
      saveGlobalProcessedMessages();
      
      processedIndexes.clear();
      isRescanning = true;
      
      console.log("[Tracker] Processing", allMessages.length, "messages");
      
      setTimeout(() => {
        // First pass: detect opponent
        allMessages.forEach(msg => {
          const lower = msg.text.toLowerCase();
          if (lower.includes("received starting resources")) {
            const match = msg.text.match(/^(.+?)\s+received starting resources/i);
            if (match) {
              const playerName = match[1].trim();
              const playerLower = playerName.toLowerCase();
              const myLower = (state.myName || "").trim().toLowerCase();
              const isMe = playerLower === "you" || playerLower === myLower;
              
              if (!isMe && !state.opponentName && !state.opponentManual) {
                state.opponentName = playerName;
                console.log("[Tracker] ✅ OPPONENT DETECTED:", state.opponentName);
              }
            }
          }
        });
        
        // Second pass: process all messages
        allMessages.forEach(msg => {
          processedIndexes.add(msg.idx);
          try {
            handleLogLine(msg.text, msg.node, msg.idx);
          } catch (e) {
            console.warn("[Tracker] Rescan error:", e, msg.text);
          }
        });
        
        isRescanning = false;
        
        // Force render
        renderHand();
        renderMyResources();
        renderDevs();
        renderDice();
        updateOpponentUI();
        saveState();
        
        progressNotif.remove();
        showNotification(`✅ Processed ${allMessages.length} messages`);
        
        console.log("[Tracker] ===== RESCAN COMPLETE =====");
      }, 100);
    });
  }

  // ─────────────────────────────────────────────────────────────────────────────
  // SECTION 11: EVENT HANDLERS
  // ─────────────────────────────────────────────────────────────────────────────

  function setupEventHandlers() {
    const gameModeSelect = $("#game-mode-select");
    if (gameModeSelect) {
      gameModeSelect.value = state.gameMode || "1v1";
      gameModeSelect.addEventListener("change", () => {
        state.gameMode = gameModeSelect.value === "4p" ? "4p" : "1v1";
        commitGameModeChange();
      });
    }

    const topGameModeBtn = $("#top-game-mode-toggle");
    if (topGameModeBtn) {
      topGameModeBtn.addEventListener("click", () => {
        state.gameMode = state.gameMode === "4p" ? "1v1" : "4p";
        commitGameModeChange();
      });
    }

    // Resource +/- buttons (1v1: data-owner; 4p: data-player-key)
    root.addEventListener("click", e => {
      const t = e.target;
      if (t.dataset && t.dataset.playerKey && t.dataset.res != null && t.dataset.delta != null) {
        trackPlayerResource4p(t.dataset.playerKey, t.dataset.res, Number(t.dataset.delta), "rolled");
        return;
      }
      if (t.dataset && t.dataset.resolveGain && t.dataset.res) {
        resolveUnknownGain4p(t.dataset.resolveGain, t.dataset.res);
        return;
      }
      if (t.dataset && t.dataset.resolveLost && t.dataset.res) {
        resolveUnknownLost4p(t.dataset.resolveLost, t.dataset.res);
        return;
      }
      if (t.dataset && t.dataset.bsRemove != null) {
        const id = parseInt(t.dataset.bsRemove, 10);
        const idx = state.blindSteals.findIndex(b => b.id === id);
        if (idx !== -1) state.blindSteals.splice(idx, 1);
        renderBlindStealsList();
        saveState();
        return;
      }
      const orderBtn = t.closest && t.closest("[data-player-order]");
      if (orderBtn && orderBtn.dataset.dir != null && state.gameMode === "4p") {
        const pk = orderBtn.dataset.playerOrder;
        if (pk) {
          movePlayerOrder4p(pk, parseInt(orderBtn.dataset.dir, 10));
          renderHand();
          saveState();
        }
        return;
      }
      if (t.dataset && t.dataset.res && t.dataset.owner) {
        const { owner, res, delta } = t.dataset;
        trackResource(owner, res, Number(delta), "rolled");
      }
    });

    root.addEventListener("change", e => {
      const t = e.target;
      if (t.type === "checkbox" && t.dataset.bsId != null && t.dataset.res) {
        const id = parseInt(t.dataset.bsId, 10);
        const res = t.dataset.res;
        const bs = state.blindSteals.find(b => b.id === id);
        if (!bs) return;
        if (!bs.possibilities) bs.possibilities = RESOURCES.slice();
        if (t.checked) {
          if (!bs.possibilities.includes(res)) bs.possibilities.push(res);
        } else {
          bs.possibilities = bs.possibilities.filter(x => x !== res);
        }
        saveState();
      }
    });

    // Username management
    const saveMyNameBtn = $("#save-myname");
    if (saveMyNameBtn) {
      saveMyNameBtn.addEventListener("click", () => {
        const input = $("#myname");
        if (input && input.value.trim()) {
          state.myName = input.value.trim();
          saveState();
          updateUsernameUI();
          showNotification("✅ Username saved");
        }
      });
    }

    const changeMyNameBtn = $("#change-myname");
    if (changeMyNameBtn) {
      changeMyNameBtn.addEventListener("click", () => {
        if (state.suppressConfirms || confirm("Change your username? This will clear your current stats.")) {
          const newName = prompt("Enter new username:", state.myName);
          if (newName && newName.trim()) {
            completeGameReset();
            state.myName = newName.trim();
            saveState();
            updateUsernameUI();
            showNotification("✅ Username changed!");
          }
        }
      });
    }

    // Opponent management
    const editOppBtn = $("#edit-opp");
    if (editOppBtn) {
      editOppBtn.addEventListener("click", () => {
        const box = $("#opp-edit-box");
        if (box) box.style.display = box.style.display === "none" ? "block" : "none";
      });
    }

    const oppSaveBtn = $("#opp-save");
    if (oppSaveBtn) {
      oppSaveBtn.addEventListener("click", () => {
        const input = $("#opp-manual");
        if (input) {
          state.opponentName = input.value.trim();
          state.opponentManual = true;
          updateOpponentUI();
          saveState();
          showNotification("✅ Opponent saved");
          const box = $("#opp-edit-box");
          if (box) box.style.display = "none";
        }
      });
    }

    const oppClearBtn = $("#opp-clear");
    if (oppClearBtn) {
      oppClearBtn.addEventListener("click", () => {
        state.opponentName = "";
        state.opponentManual = false;
        updateOpponentUI();
        saveState();
        const box = $("#opp-edit-box");
        if (box) box.style.display = "none";
        showNotification("✅ Opponent cleared");
      });
    }

    // Rescan button
    const rescanBtn = $("#rescan-log-btn");
    if (rescanBtn) {
      rescanBtn.addEventListener("click", () => {
        if (state.suppressConfirms || confirm("🔄 Rescan entire game log?\n\nThis will recheck all stats from scratch.")) {
          rescanEntireLog();
        }
      });
    }

    const startNewGame = () => {
      if (state.suppressConfirms || confirm("🆕 Start new game? This will clear all stats.")) {
        completeGameReset();
        showNotification("✅ New game started!");
      }
    };

    // New game button (top header)
    const topNewGameBtn = $("#top-new-game");
    if (topNewGameBtn) {
      topNewGameBtn.addEventListener("click", startNewGame);
    }

    // New game button
    const fullResetBtn = $("#full-reset");
    if (fullResetBtn) {
      fullResetBtn.addEventListener("click", startNewGame);
    }

    // Copy stats button
    const copyStatsBtn = $("#copy-stats-btn");
    if (copyStatsBtn) {
      copyStatsBtn.addEventListener("click", () => {
        copyStatsToClipboard();
      });
    }

    // Clear buttons
    const diceClearBtn = $("#dice-clear");
    if (diceClearBtn) {
      diceClearBtn.addEventListener("click", () => {
        state.dice = [];
        state.sevensYou = 0;
        state.sevensOpp = 0;
        if (state.gameMode === "4p") {
          Object.values(state.players).forEach(p => { p.sevens = 0; });
        }
        renderDice();
        saveState();
      });
    }

    const handClearBtn = $("#hand-clear");
    if (handClearBtn) {
      handClearBtn.addEventListener("click", () => {
        if (state.gameMode === "4p") {
          Object.values(state.players).forEach(p => {
            if (!p.isMe) {
              p.resources = createEmptyResources();
              p.tracking = createResourceTracking();
              p.unknownGained = 0;
              p.unknownLost = 0;
              p.devCardsHeld = 0;
            }
          });
          state.blindSteals = [];
        } else {
          state.resources = createEmptyResources();
          state.oppTracking = createResourceTracking();
        }
        renderHand();
        renderBlindStealsList();
        saveState();
      });
    }

    const myresClearBtn = $("#myres-clear");
    if (myresClearBtn) {
      myresClearBtn.addEventListener("click", () => {
        if (state.gameMode === "4p") {
          const me = ensurePlayerRecord(state.myName, true);
          if (me) {
            me.resources = createEmptyResources();
            me.tracking = createResourceTracking();
            me.unknownGained = 0;
            me.unknownLost = 0;
            me.devCardsHeld = 0;
          }
        }
        state.myResources = createEmptyResources();
        state.myTracking = createResourceTracking();
        renderMyResources();
        renderHand();
        saveState();
      });
    }

    const devClearBtn = $("#dev-clear");
    if (devClearBtn) {
      devClearBtn.addEventListener("click", () => {
        state.devUsed = createEmptyDevUsed();
        state.devPurchased = 0;
        renderDevs();
        saveState();
      });
    }

    // Collapse toggle
    const collapseToggle = $("#catan-collapse-toggle");
    if (collapseToggle) {
      collapseToggle.addEventListener("click", () => {
        state.collapsed = !state.collapsed;
        applyCollapsed();
        saveState();
      });
    }

    // Save current game
    const saveGameBtn = $("#save-current-game");
    if (saveGameBtn) {
      saveGameBtn.addEventListener("click", () => {
        if (saveCurrentGame()) {
          showNotification("✅ Game saved!");
        } else {
          showNotification("⚠️ Not enough data to save!", "warning");
        }
      });
    }

    // Minimize buttons
    const minimizeMap = {
      'dice-minimize': 'dice',
      'opphand-minimize': 'oppHand',
      'myres-minimize': 'myRes',
      'dev-minimize': 'devCards',
      'history-minimize': 'history'
    };

    Object.entries(minimizeMap).forEach(([btnId, stateKey]) => {
      const btn = $(`#${btnId}`);
      if (btn) {
        btn.addEventListener("click", () => {
          state.minimized[stateKey] = !state.minimized[stateKey];
          applyMinimized();
          saveState();
        });
      }
    });

    // Info popup
    const infoBtn = $("#catan-info-toggle");
    const infoOverlay = $("#info-popup-overlay");
    const infoClose = $("#info-popup-close");
    const catanBody = $("#catan-body");

    if (infoBtn && infoOverlay && catanBody) {
      infoBtn.addEventListener("click", (e) => {
        e.stopPropagation();
        const isShowing = infoOverlay.classList.contains("show");
        if (isShowing) {
          infoOverlay.classList.remove("show");
          catanBody.style.display = "";
        } else {
          infoOverlay.classList.add("show");
          catanBody.style.display = "none";
        }
      });
    }

    if (infoClose && infoOverlay && catanBody) {
      infoClose.addEventListener("click", () => {
        infoOverlay.classList.remove("show");
        catanBody.style.display = "";
      });
    }

    // Suppress confirmations
    const suppressCheckbox = $("#suppress-confirms");
    if (suppressCheckbox) {
      suppressCheckbox.checked = state.suppressConfirms || false;

      suppressCheckbox.addEventListener("change", (e) => {
        state.suppressConfirms = e.target.checked;
        saveSuppressConfirms(state.suppressConfirms);
        saveState();
      });
    }

    // Dev card tooltip positioning
    const diceButton = $("#show-dice-popup");
    const diceTooltip = $("#dice-collapsed-tooltip");
    if (diceButton && diceTooltip) {
      const positionDiceTooltip = () => {
        const buttonRect = diceButton.getBoundingClientRect();
        diceTooltip.style.top = (buttonRect.top - diceTooltip.offsetHeight - 10) + "px";
        diceTooltip.style.left = (buttonRect.right - 250) + "px";
      };
      diceButton.addEventListener("mouseenter", positionDiceTooltip);
      diceTooltip.addEventListener("mouseenter", positionDiceTooltip);
    }

    // Dev card tooltip positioning
    const devButton = $("#show-dev-popup");
    const devTooltip = $("#dev-card-tooltip");

    if (devButton && devTooltip) {
      const positionTooltip = () => {
        const buttonRect = devButton.getBoundingClientRect();
        devTooltip.style.top = (buttonRect.top - devTooltip.offsetHeight - 10) + 'px';
        devTooltip.style.left = (buttonRect.right - 240) + 'px';
      };

      devButton.addEventListener("mouseenter", positionTooltip);
      devTooltip.addEventListener("mouseenter", positionTooltip);
    }

    // Drag & drop for sections
    initDragDrop();

    // Panel dragging
    let dragging = false;
    let offsetX = 0;
    let offsetY = 0;

    root.addEventListener("mousedown", e => {
      if (e.target.tagName === 'BUTTON' ||
          e.target.tagName === 'INPUT' ||
          e.target.tagName === 'A' ||
          e.target.closest('button') ||
          e.target.closest('input') ||
          e.target.closest('a') ||
          e.target.closest('.res-buttons') ||
          e.target.closest('.section-header') ||
          e.target.closest('.section-content') ||
          e.target.closest('.tracker-body-wrapper')) {
        return;
      }

      dragging = true;
      const rect = root.getBoundingClientRect();
      root.style.left = rect.left + "px";
      root.style.top = rect.top + "px";
      root.style.right = "auto";
      offsetX = e.clientX - rect.left;
      offsetY = e.clientY - rect.top;
      e.preventDefault();
    });

    window.addEventListener("mousemove", e => {
      if (dragging) {
        const clamped = getClampedPanelPosition(e.clientX - offsetX, e.clientY - offsetY);
        root.style.left = `${clamped.left}px`;
        root.style.top = `${clamped.top}px`;
      }
    });

    window.addEventListener("mouseup", () => {
      if (dragging) {
        savePanelPosition(parseFloat(root.style.left) || 0, parseFloat(root.style.top) || 0);
      }
      dragging = false;
    });

    window.addEventListener("resize", () => {
      if (!root || !root.style.left || !root.style.top) return;
      applyPanelPosition({
        left: parseFloat(root.style.left) || 0,
        top: parseFloat(root.style.top) || 0
      });
    });
  }

  function initDragDrop() {
    const body = $("#catan-body");
    if (!body) return;

    let draggedElement = null;

    body.querySelectorAll(".section").forEach((section, index) => {
      section.setAttribute("data-section-index", index);

      const header = section.querySelector(".section-header");
      if (!header) return;

      header.setAttribute("draggable", "true");

      header.addEventListener("mousedown", e => e.stopPropagation());
      header.querySelectorAll("button").forEach(btn => {
        btn.addEventListener("mousedown", e => e.stopPropagation());
        btn.addEventListener("dragstart", e => {
          e.preventDefault();
          e.stopPropagation();
        });
      });

      header.addEventListener("dragstart", e => {
        if (e.target.tagName === "BUTTON" || e.target.closest("button")) {
          e.preventDefault();
          return;
        }

        draggedElement = section;
        section.classList.add("dragging");
        e.dataTransfer.effectAllowed = "move";
        e.dataTransfer.setData("text/html", "section-drag");
        e.stopPropagation();
      });

      header.addEventListener("dragend", () => {
        section.classList.remove("dragging");
        body.querySelectorAll(".section").forEach(s => s.classList.remove("drag-over"));
        draggedElement = null;
      });

      section.addEventListener("dragover", e => {
        e.preventDefault();
        e.stopPropagation();
        e.dataTransfer.dropEffect = "move";
        if (draggedElement && draggedElement !== section) {
          section.classList.add("drag-over");
        }
      });

      section.addEventListener("dragleave", e => {
        if (!section.contains(e.relatedTarget)) {
          section.classList.remove("drag-over");
        }
      });

      section.addEventListener("drop", e => {
        e.preventDefault();
        e.stopPropagation();
        section.classList.remove("drag-over");

        if (!draggedElement || draggedElement === section) return;

        const rect = section.getBoundingClientRect();
        const dropBefore = e.clientY < rect.top + rect.height / 2;
        body.insertBefore(draggedElement, dropBefore ? section : section.nextSibling);

        // Save new order
        const order = [];
        body.querySelectorAll(".section").forEach(s => {
          const headerText = s.querySelector(".section-header strong");
          if (headerText) order.push(headerText.textContent.trim());
        });

        state.sectionOrder = order;
        saveState();
      });
    });
  }

  // ─────────────────────────────────────────────────────────────────────────────
  // SECTION 12: INITIALIZATION & BOOT
  // ─────────────────────────────────────────────────────────────────────────────

  function injectPanel() {
    if (document.getElementById(TRACKER_ID)) {
      return document.getElementById(TRACKER_ID);
    }

    injectTrackerStyles();

    root = document.createElement("div");
    root.id = TRACKER_ID;
    root.innerHTML = buildTrackerHTML();
    root.style.visibility = "hidden";
    document.body.appendChild(root);

    // Apply saved position before first paint to avoid right-side "jump".
    applyPanelPosition(loadPanelPosition());

    console.log("[Tracker] Panel injected");
    return root;
  }

  function initTracker() {
    console.log("[Tracker] Initializing...");

    // Load state
    state = loadState();
    gameHistory = loadGameHistory();
    GLOBAL_PROCESSED_MESSAGES = loadGlobalProcessedMessages();

    // Check for permanent suppress setting
    const savedSuppressConfirms = loadSuppressConfirms();
    if (typeof savedSuppressConfirms === "boolean") {
      state.suppressConfirms = savedSuppressConfirms;
    }

    const savedCollapsed = loadPanelCollapsed();
    if (typeof savedCollapsed === "boolean") {
      state.collapsed = savedCollapsed;
    }

    // Set username input value
    const mynameInput = $("#myname");
    if (mynameInput && state.myName) {
      mynameInput.value = state.myName;
    }

    // Initial render
    renderAll();
    renderHistory();
    applyCollapsed();
    applyMinimized();
    applySectionOrder();
    applyPanelPosition(loadPanelPosition());

    // Setup events
    setupEventHandlers();

    // Start log scanning
    setInterval(scanLog, TIMING.scanInterval);

    // Reveal after all state-driven layout has been applied.
    if (root) {
      root.style.visibility = "visible";
    }

    console.log("[Tracker] ✅ Initialization complete");
  }

  function boot() {
    console.log("[Tracker] Booting...");

    root = injectPanel();

    if (root) {
      initTracker();
      console.log(`[Catan Tracker] ✅ Running v${TRACKER_VERSION}`);
    }
  }

  function survivalCheck() {
    const existingRoot = document.getElementById(TRACKER_ID);

    if (!existingRoot) {
      console.log("[Tracker] Panel missing, re-injecting...");
      boot();
    } else {
      existingRoot.style.zIndex = "99999999";
      existingRoot.style.pointerEvents = "auto";

      if (document.body.lastElementChild !== existingRoot) {
        document.body.appendChild(existingRoot);
      }
    }
  }

  // Start
  if (document.readyState === "loading") {
    window.addEventListener("DOMContentLoaded", boot);
  } else {
    boot();
  }

  // Survival interval
  setInterval(survivalCheck, TIMING.survivalCheckInterval);

})();